-- CONFRONTIAMO LE PRESTAZIONI DI UNA QUERY PRIMA E DOPO LA CREAZIONE DI UN INDICE (1)
-- Crea un indice parziale su piano_dieta per i piani attuali (data_fine IS NULL)
CREATE INDEX idx_piano_attuale_cf_paziente
ON piano_dieta (cf_paziente)
WHERE data_fine IS NULL;

-- Prepara il contesto:
ANALYZE;

-- Invia la query SQL prima SENZA indice:
EXPLAIN (ANALYZE, BUFFERS)
SELECT DISTINCT
    p.cf,
    p.nome,
    p.cognome
FROM paziente p
JOIN piano_dieta pd ON pd.cf_paziente = p.cf
WHERE pd.data_fine IS NULL;

-- Creazione dell'indice:
CREATE INDEX idx_piano_attuale_cf_paziente
ON piano_dieta (cf_paziente)
WHERE data_fine IS NULL;

-- Aggiorna le statistiche dopo la creazione dell'indice:
ANALYZE piano_dieta;

-- Invia di nuovo la query SQL ora CON l’indice:
EXPLAIN (ANALYZE, BUFFERS)
SELECT DISTINCT
    p.cf,
    p.nome,
    p.cognome
FROM paziente p
JOIN piano_dieta pd ON pd.cf_paziente = p.cf
WHERE pd.data_fine IS NULL;

-- CONFRONTIAMO LE PRESTAZIONI DI UNA QUERY PRIMA E DOPO LA CREAZIONE DI UN INDICE (2)
-- Creazione dell'indice relativo all'attributo 'peso' del paziente per filtrare i pazienti con peso > 80

-- Prepara il contesto:
ANALYZE;

-- Invia la query SQL prima SENZA indice:
EXPLAIN (ANALYZE, BUFFERS)
SELECT nome, cognome
FROM paziente
WHERE peso > 100;

-- Creazione dell'indice:
CREATE INDEX idx_paziente_peso
ON PAZIENTE (peso);

-- Aggiorna le statistiche dopo la creazione dell'indice:
ANALYZE paziente;

-- Invia di nuovo la query SQL ora CON l’indice:
EXPLAIN (ANALYZE, BUFFERS)
SELECT nome, cognome
FROM paziente
WHERE peso > 100;

-- CONFRONTIAMO LE PRESTAZIONI DI UNA QUERY PRIMA E DOPO LA CREAZIONE DI UN INDICE (3)

-- Prepara il contesto:
ANALYZE;

-- Invia la query SQL prima SENZA indice:
EXPLAIN (ANALYZE, BUFFERS)
SELECT codice, data_esecuzione, esito
FROM RISULTATO_TEST_GENETICO
WHERE cf_paziente = 'RSSMRI80A01H501U'  -- Filtro 1 (Colonna primaria dell'indice)
  AND data_esecuzione BETWEEN '2023-01-01' AND '2023-12-31'; -- Filtro 2 (Colonna secondaria)

-- Creazione di un Indice Composito sulla tabella RISULTATO_TEST_GENETICO
-- Ordina fisicamente i puntatori prima per CF del paziente, e poi per Data di esecuzione.
CREATE INDEX idx_test_paziente_data 
ON RISULTATO_TEST_GENETICO (cf_paziente, data_esecuzione);

-- Aggiorna le statistiche dopo la creazione dell'indice:
ANALYZE RISULTATO_TEST_GENETICO;

-- Invia di nuovo la query SQL ora CON l’indice:
EXPLAIN (ANALYZE, BUFFERS)
SELECT codice, data_esecuzione, esito
FROM RISULTATO_TEST_GENETICO
WHERE cf_paziente = 'RSSMRI80A01H501U'  -- Filtro 1 (Colonna primaria dell'indice)
  AND data_esecuzione BETWEEN '2023-01-01' AND '2023-12-31'; -- Filtro 2 (Colonna secondaria)

-- ============================================================
-- Fine file indici
-- ============================================================