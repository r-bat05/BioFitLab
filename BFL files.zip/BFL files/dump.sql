BEGIN;

-- ============================================================
-- MEDICO  
-- ============================================================
INSERT INTO MEDICO VALUES
('MDCRSS80A01F205X','Mario','Rossi','rossi@med.it','333111','Via Roma 1','Uni Bari','1980-01-01','Bari'),
('MDCBNCH75B02F205','Luigi','Bianchi','bianchi@med.it','333112','Via Napoli 2','Uni Roma','1975-02-02','Bari'),
('MDCLVR82C03F205Z','Paolo','Verdi','verdi@med.it','333113','Via Lecce 3','Uni Milano','1982-03-03','Bari');

-- ============================================================
-- NUTRIZIONISTA  
-- ============================================================
INSERT INTO NUTRIZIONISTA VALUES
('NTRLCU85A01F205X','Luca','Neri','1985-01-01','333221','luca@nutri.it','Via Dante 1','Via Bari 1'),
('NTRMRC90B02F205Y','Marco','Rosa','1990-02-02','333222','marco@nutri.it','Via Dante 2','Via Bari 2'),
('NTRANN88C03F205Z','Anna','Blu','1988-03-03','333223','anna@nutri.it','Via Dante 3','Via Bari 3');

-- ============================================================
-- ABILITAZIONE  
-- ============================================================
INSERT INTO ABILITAZIONE VALUES
('AB01','Ministero','Nutrizione',3),
('AB02','Ministero','Sport',4),
('AB03','Regione','Clinica',5);

-- ============================================================
-- CERTIFICAZIONE  
-- ============================================================
INSERT INTO CERTIFICAZIONE VALUES
('NTRLCU85A01F205X','AB01','2015-01-01'),
('NTRMRC90B02F205Y','AB02','2016-01-01'),
('NTRANN88C03F205Z','AB03','2017-01-01');

-- ============================================================
-- DIETA  
-- ============================================================
INSERT INTO DIETA VALUES
('Mediterranea','1.0','Dimagrimento','Bilanciata'),
('Chetogenica','1.0','Definizione','Low Carb'),
('Sportiva','1.0','Performance','Iperproteica');

-- ============================================================
-- ALIMENTO  
-- ============================================================
INSERT INTO ALIMENTO VALUES
('AL01','Pasta','Glutine',6,2,12,70,350),
('AL02','Riso',NULL,2,1,7,78,360),
('AL03','Pollo',NULL,0,1,23,0,120);

-- ============================================================
-- PAZIENTE
-- ============================================================
INSERT INTO PAZIENTE (cf, nome, cognome, data_nascita, telefono, email, peso, altezza, indirizzo, data_inizio_medico, data_inizio_nutrizionista, cf_medico, cf_nutrizionista, citta_residenza) VALUES
('PZK0E1YA8PUJBFK5', 'Laura', 'Leone', '1998-10-21', '3333010064', 'laura.leone.17@email.com', 70.0, 1.64, 'Via Francesca 57', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZMKWDNKRHT6DQA5', 'Davide', 'Rinaldi', '2000-07-12', '3335604935', 'davide.rinaldi.165@email.com', 120.0, 1.88, 'Via Luca 77', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZOGL3EO82JYO6V7', 'Daniela', 'Mariani', '1985-07-26', '3338835773', 'daniela.mariani.3@email.com', 70.0, 1.75, 'Via Vittoria 85', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUWMP3ZO345G6EF', 'Antonio', 'Marchetti', '1995-07-24', '3337780133', 'antonio.marchetti.188@email.com', 70.0, 1.64, 'Via Davide 51', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ3QL2QFKK0RODIN', 'Francesca', 'Rossi', '1998-12-20', '3337771644', 'francesca.rossi.107@email.com', 120.0, 1.65, 'Via Angelo 50', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZNTRZEAZ46DGEVW', 'Roberto', 'Gatti', '1981-11-24', '3336776596', 'roberto.gatti.39@email.com', 70.0, 1.71, 'Via Nicola 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ7SEUDF38G1JE3E', 'Lorenzo', 'Riva', '1985-08-17', '3334012641', 'lorenzo.riva.155@email.com', 70.0, 1.71, 'Via Anna 61', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZK8XYC94RXHAEQX', 'Andrea', 'Bruno', '1998-12-13', '3337396057', 'andrea.bruno.123@email.com', 70.0, 1.73, 'Via Matteo 19', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZQGZ4IGFF8564MP', 'Angelo', 'Romano', '1972-12-04', '3331531522', 'angelo.romano.175@email.com', 70.0, 1.61, 'Via Maria 25', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZW3ALR8K4TNY15Q', 'Elena', 'Caruso', '1963-06-17', '3333866945', 'elena.caruso.44@email.com', 70.0, 1.82, 'Via Pietro 88', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZRAV4UQU70DOAL7', 'Alessandro', 'Riva', '1982-06-20', '3332604320', 'alessandro.riva.48@email.com', 70.0, 1.91, 'Via Angelo 70', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ4XTANG7IGCB8U0', 'Francesca', 'Monti', '1980-09-21', '3337454297', 'francesca.monti.79@email.com', 70.0, 1.91, 'Via Antonio 64', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZCDRUD9Z3JSF1J9', 'Lorenzo', 'Longo', '1961-07-19', '3331657334', 'lorenzo.longo.22@email.com', 70.0, 1.76, 'Via Sofia 78', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZIO0M1UKHI1Y6FD', 'Beatrice', 'Ferrari', '1980-04-15', '3337212808', 'beatrice.ferrari.127@email.com', 70.0, 1.78, 'Via Greta 52', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ4WSAT51562WOVH', 'Silvia', 'Fabbri', '1966-03-18', '3333864771', 'silvia.fabbri.156@email.com', 70.0, 1.74, 'Via Edoardo 60', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ31ZD24CIXJ19YJ', 'Alessia', 'Villa', '1973-07-23', '3332467991', 'alessia.villa.144@email.com', 70.0, 1.72, 'Via Ginevra 76', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZJEK1H5KKM1K4BG', 'Alessia', 'Mazza', '2003-08-17', '3338656608', 'alessia.mazza.86@email.com', 70.0, 1.6, 'Via Laura 73', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ3SLHRNLAYDMAVM', 'Beatrice', 'Marino', '2003-02-18', '3333040584', 'beatrice.marino.145@email.com', 70.0, 1.83, 'Via Davide 52', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZH8ORUS9NGLNQZS', 'Laura', 'Marino', '1977-06-14', '3339466358', 'laura.marino.18@email.com', 70.0, 1.7, 'Via Raffaele 24', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZV6PP8G1DY6OQCM', 'Salvatore', 'Marino', '1990-08-01', '3334194257', 'salvatore.marino.142@email.com', 120.0, 1.65, 'Via Alice 60', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZRUF8J7824VIDIH', 'Paola', 'Rossi', '1981-06-09', '3334870723', 'paola.rossi.116@email.com', 70.0, 1.93, 'Via Nicola 76', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ1V3BW10RXFHU6X', 'Riccardo', 'Rinaldi', '1976-01-22', '3333607723', 'riccardo.rinaldi.8@email.com', 70.0, 1.95, 'Via Angelo 77', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZK786XZX5DVGUUW', 'Ludovica', 'De Santis', '1964-08-24', '3338151407', 'ludovica.desantis.85@email.com', 70.0, 1.65, 'Via Gabriele 13', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ8YVWP57KBYF7GA', 'Andrea', 'Fontana', '1970-03-11', '3337977451', 'andrea.fontana.195@email.com', 70.0, 1.76, 'Via Francesco 51', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZQUOHY9IX8X15CG', 'Michele', 'Parisi', '1989-09-05', '3336954011', 'michele.parisi.102@email.com', 70.0, 1.8, 'Via Valentina 100', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZK70HFEEFRRYQUL', 'Massimo', 'Fontana', '1979-08-10', '3333886708', 'massimo.fontana.87@email.com', 70.0, 1.73, 'Via Elena 13', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ7NFBXQHN8N9EH7', 'Andrea', 'Russo', '1973-10-23', '3335433668', 'andrea.russo.118@email.com', 70.0, 1.93, 'Via Pietro 98', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ4LKLR4EGPN2OIV', 'Pietro', 'Gatti', '1971-12-21', '3333724157', 'pietro.gatti.146@email.com', 70.0, 1.95, 'Via Salvatore 81', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZT5WPB80UJZEFWT', 'Alessia', 'Bruno', '1981-10-24', '3332677995', 'alessia.bruno.89@email.com', 70.0, 1.78, 'Via Arianna 46', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZDD8P69T4RJ6GEG', 'Simone', 'Caruso', '1978-03-16', '3331425560', 'simone.caruso.167@email.com', 70.0, 1.92, 'Via Laura 72', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZXRA0AMIOH9TISL', 'Alice', 'Monti', '1974-06-01', '3334432751', 'alice.monti.27@email.com', 70.0, 1.73, 'Via Paolo 7', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZKWUVPVN3KM9HF7', 'Leonardo', 'Greco', '1988-09-21', '3337426939', 'leonardo.greco.194@email.com', 70.0, 1.79, 'Via Sergio 51', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZBRZC9J7HPZDAG1', 'Maria', 'Fabbri', '1966-12-28', '3337056161', 'maria.fabbri.192@email.com', 70.0, 1.77, 'Via Elena 79', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZNUD1EA1R75M69C', 'Vittoria', 'De Santis', '1964-09-03', '3338504281', 'vittoria.desantis.46@email.com', 70.0, 1.93, 'Via Alice 37', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ312WHL7TEV3TLW', 'Anna', 'Costa', '1994-12-18', '3336059889', 'anna.costa.83@email.com', 70.0, 1.93, 'Via Maria 50', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ7GHWWJAMT27CYB', 'Francesco', 'D''Angelo', '1990-05-19', '3338906999', 'francesco.dangelo.92@email.com', 70.0, 1.94, 'Via Giovanni 8', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZYLPWACIQXST8AY', 'Angelo', 'Mancini', '1986-10-02', '3332522967', 'angelo.mancini.64@email.com', 70.0, 1.78, 'Via Gaia 72', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ1STXPBCZ6MEV18', 'Martina', 'Ferri', '2001-02-17', '3334145906', 'martina.ferri.122@email.com', 70.0, 1.79, 'Via Marco 78', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZZ0ELPJV2WHYMHA', 'Giulia', 'Amato', '1969-01-27', '3332093797', 'giulia.amato.185@email.com', 70.0, 1.71, 'Via Gaia 79', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZI5KO0F6BOMPH40', 'Edoardo', 'Conti', '1972-07-23', '3337958954', 'edoardo.conti.148@email.com', 70.0, 1.72, 'Via Lorenzo 14', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZIEL3MDXQ48LT2K', 'Edoardo', 'De Santis', '1978-04-25', '3331006352', 'edoardo.desantis.5@email.com', 70.0, 1.67, 'Via Antonio 29', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZXWYX0G1AJFR3CL', 'Pietro', 'Bianco', '1998-11-27', '3338358461', 'pietro.bianco.143@email.com', 70.0, 1.76, 'Via Vincenzo 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZIH8EYYULL9FU7V', 'Aurora', 'Costa', '2000-05-11', '3332010759', 'aurora.costa.53@email.com', 70.0, 1.89, 'Via Alice 56', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ6RUBM41Q32XV6L', 'Giuseppe', 'Romano', '2003-04-19', '3334707473', 'giuseppe.romano.104@email.com', 120.0, 1.62, 'Via Federico 14', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ4JLJDKE7L7ZVDZ', 'Salvatore', 'Marino', '2000-11-11', '3333888526', 'salvatore.marino.15@email.com', 70.0, 1.62, 'Via Leonardo 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZQAQBOZUW37HYM8', 'Andrea', 'Giordano', '1988-03-05', '3333127447', 'andrea.giordano.2@email.com', 70.0, 1.65, 'Via Simone 3', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZVQZSL3C8GV7M2G', 'Sofia', 'Vitale', '1996-10-23', '3336380991', 'sofia.vitale.161@email.com', 70.0, 1.79, 'Via Pietro 55', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZR61JQXYXYTTRP6', 'Roberto', 'Barbieri', '1967-05-04', '3337348123', 'roberto.barbieri.125@email.com', 120.0, 1.88, 'Via Giorgio 77', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ69F9OCTSL8OQKV', 'Maria', 'De Santis', '1963-09-08', '3334366827', 'maria.desantis.81@email.com', 70.0, 1.74, 'Via Vittoria 38', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZYQT7RWBNYHZE0C', 'Salvatore', 'Marchetti', '1965-05-22', '3335479619', 'salvatore.marchetti.65@email.com', 70.0, 1.67, 'Via Federico 22', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZVFBOA5BAD9UJK1', 'Paolo', 'Farina', '1968-07-09', '3336829268', 'paolo.farina.162@email.com', 70.0, 1.82, 'Via Nicola 6', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZR3CY9C8EB13KZ4', 'Edoardo', 'Gallo', '1977-12-27', '3335236220', 'edoardo.gallo.105@email.com', 70.0, 1.9, 'Via Aurora 42', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZVCX9G4IUP4R06Q', 'Francesca', 'Bruno', '1985-12-10', '3331229462', 'francesca.bruno.174@email.com', 120.0, 1.65, 'Via Fabio 43', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZYJ0TQI50ZJ6WH1', 'Massimo', 'Parisi', '1979-11-10', '3334560628', 'massimo.parisi.184@email.com', 70.0, 1.75, 'Via Mauro 90', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZF794JBKJOLW3BI', 'Vittoria', 'Fabbri', '1984-05-27', '3338871288', 'vittoria.fabbri.78@email.com', 70.0, 1.88, 'Via Francesca 61', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZLVJZ587CRUSAEU', 'Valentina', 'Greco', '2001-12-06', '3339927553', 'valentina.greco.173@email.com', 70.0, 1.74, 'Via Andrea 85', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZI3C0F1E0RZ6MMR', 'Maria', 'Giordano', '1965-02-27', '3334941237', 'maria.giordano.106@email.com', 70.0, 1.93, 'Via Giorgio 96', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ1YPQ82S3XXZAGM', 'Francesco', 'Galli', '1990-01-02', '3339084320', 'francesco.galli.120@email.com', 70.0, 1.62, 'Via Nicole 69', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZWJ8N9FE2Y5UKXZ', 'Alice', 'Ferraro', '1991-12-14', '3337273485', 'alice.ferraro.113@email.com', 70.0, 1.94, 'Via Paola 81', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZTMV9635PXNIJUY', 'Greta', 'Fontana', '1985-04-11', '3337342765', 'greta.fontana.26@email.com', 70.0, 1.69, 'Via Mattia 37', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ6UHYJF9EOF24WY', 'Simone', 'Villa', '1983-08-09', '3336950096', 'simone.villa.100@email.com', 70.0, 1.77, 'Via Martina 60', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ7RQIF7A3YOA6YE', 'Gabriele', 'Longo', '1970-06-28', '3336645771', 'gabriele.longo.137@email.com', 70.0, 1.82, 'Via Aurora 24', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZH0ROQ8DRAKNSYR', 'Fabio', 'Sanna', '2002-10-11', '3331557120', 'fabio.sanna.186@email.com', 70.0, 1.73, 'Via Arianna 37', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ2O11ZTHSGRZKRR', 'Alessia', 'Monti', '1993-01-09', '3334060861', 'alessia.monti.160@email.com', 70.0, 1.7, 'Via Matteo 55', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZFX6BNDY6FQ0UCB', 'Francesco', 'Esposito', '1967-08-07', '3337153827', 'francesco.esposito.7@email.com', 70.0, 1.66, 'Via Fabio 80', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ3TJWIOA9FJFP0A', 'Daniela', 'Giordano', '1982-09-08', '3336435068', 'daniela.giordano.135@email.com', 70.0, 1.73, 'Via Francesco 96', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMQ5MHLHCZJHVHN', 'Francesca', 'Marchetti', '1979-09-10', '3338995579', 'francesca.marchetti.197@email.com', 120.0, 1.89, 'Via Leonardo 73', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZTMWTBH8RTVH0QC', 'Chiara', 'Romano', '1994-10-07', '3333970739', 'chiara.romano.134@email.com', 70.0, 1.79, 'Via Luca 58', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZB57F2AI0GI0PQM', 'Federico', 'Rizzo', '1990-03-13', '3334987831', 'federico.rizzo.129@email.com', 70.0, 1.76, 'Via Laura 100', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZUVKALVZ27GSXAA', 'Simone', 'Monti', '1962-05-08', '3331110990', 'simone.monti.20@email.com', 70.0, 1.84, 'Via Nicole 21', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZOZ7HG512ZGQUK6', 'Simone', 'Parisi', '1961-07-22', '3334926156', 'simone.parisi.178@email.com', 70.0, 1.93, 'Via Federico 12', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ8FNF7XVOJQKIGG', 'Lorenzo', 'Sanna', '1994-11-03', '3337887926', 'lorenzo.sanna.14@email.com', 70.0, 1.75, 'Via Simone 20', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMUYSE7FA5FUDCU', 'Roberto', 'Fontana', '2000-03-19', '3337840609', 'roberto.fontana.66@email.com', 70.0, 1.9, 'Via Alice 24', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZBQXZRGTO4MG63I', 'Mattia', 'Longo', '1999-07-01', '3331184026', 'mattia.longo.9@email.com', 70.0, 1.73, 'Via Sara 15', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ3VDG2QXF5NIXE5', 'Claudio', 'Colombo', '1961-01-01', '3338503598', 'claudio.colombo.24@email.com', 70.0, 1.68, 'Via Giorgia 69', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZJDGG5W0YN7UE1B', 'Pietro', 'D''Angelo', '1971-06-08', '3332118846', 'pietro.dangelo.190@email.com', 70.0, 1.91, 'Via Claudio 66', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ6CANCTO9JNOXJU', 'Cristina', 'Gallo', '1989-04-23', '3332290335', 'cristina.gallo.115@email.com', 70.0, 1.85, 'Via Alessia 41', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZW5BOU47891JX3M', 'Tommaso', 'Moretti', '1984-06-01', '3332605714', 'tommaso.moretti.131@email.com', 70.0, 1.66, 'Via Emma 94', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZWHG5S5IHP593GO', 'Nicole', 'Montanari', '1975-03-18', '3336238683', 'nicole.montanari.67@email.com', 70.0, 1.8, 'Via Sergio 55', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ954OPOO8TS3462', 'Martina', 'Ricci', '1993-07-13', '3331949752', 'martina.ricci.98@email.com', 70.0, 1.93, 'Via Giovanni 11', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZFF7KS1SUILY6K9', 'Domenico', 'Santoro', '1975-01-02', '3337404677', 'domenico.santoro.60@email.com', 70.0, 1.9, 'Via Giulia 49', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ8HGVM1JSM7CF2F', 'Enrico', 'Farina', '1974-03-13', '3334262758', 'enrico.farina.152@email.com', 70.0, 1.65, 'Via Paolo 19', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZQOND7F3URO7PT3', 'Sara', 'Rizzo', '1967-04-18', '3333300469', 'sara.rizzo.179@email.com', 70.0, 1.63, 'Via Enrico 64', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZNSM2B991EWV5C1', 'Aurora', 'Parisi', '1972-03-25', '3337916667', 'aurora.parisi.80@email.com', 70.0, 1.84, 'Via Silvia 94', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZW0DATQ3LVQI8X6', 'Salvatore', 'Galli', '1986-04-12', '3334096330', 'salvatore.galli.82@email.com', 70.0, 1.8, 'Via Nicole 61', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZUU0LGQPKJ2CKJV', 'Elena', 'Colombo', '1978-03-25', '3337399966', 'elena.colombo.84@email.com', 70.0, 1.85, 'Via Domenico 61', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUTG0WWX4JZKYSS', 'Roberto', 'De Luca', '1985-06-09', '3332982911', 'roberto.deluca.139@email.com', 70.0, 1.82, 'Via Simone 95', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZMKLE6733MYEW0X', 'Riccardo', 'Riva', '1989-11-19', '3332510934', 'riccardo.riva.154@email.com', 70.0, 1.7, 'Via Alice 12', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ4UPYZIPTO985J4', 'Mattia', 'D''Angelo', '1977-03-01', '3331782940', 'mattia.dangelo.149@email.com', 70.0, 1.93, 'Via Beatrice 91', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZB29909C4QEWU9Z', 'Aurora', 'Lombardi', '1990-02-25', '3331243623', 'aurora.lombardi.11@email.com', 70.0, 1.87, 'Via Laura 30', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZFRHJ35HTT1J8OO', 'Francesca', 'Lombardo', '1980-09-01', '3331694972', 'francesca.lombardo.163@email.com', 70.0, 1.62, 'Via Giuseppe 7', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZA3ZQSTEG6B0M5G', 'Paola', 'Bianco', '1970-02-07', '3336940424', 'paola.bianco.168@email.com', 70.0, 1.92, 'Via Camilla 5', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZU5701OF2CMBZDO', 'Lorenzo', 'Ferri', '1998-04-17', '3335009914', 'lorenzo.ferri.199@email.com', 70.0, 1.89, 'Via Antonio 59', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZFCWLQTIEN35N5C', 'Riccardo', 'Vitale', '1987-04-28', '3339981784', 'riccardo.vitale.33@email.com', 70.0, 1.95, 'Via Ginevra 54', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZJAKZ75W2P0LO3S', 'Massimo', 'Rinaldi', '1968-10-19', '3338131697', 'massimo.rinaldi.77@email.com', 70.0, 1.91, 'Via Gaia 93', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ57T80QHTB7TE17', 'Claudio', 'Amato', '1982-09-19', '3334550775', 'claudio.amato.183@email.com', 70.0, 1.76, 'Via Giulia 69', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUG2IHTC7ANPL3R', 'Arianna', 'Russo', '1981-03-19', '3335122521', 'arianna.russo.56@email.com', 70.0, 1.78, 'Via Luigi 7', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZBJU4KL3T2KBUMU', 'Valentina', 'De Luca', '1993-04-19', '3332268451', 'valentina.deluca.19@email.com', 70.0, 1.92, 'Via Rosario 61', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZK50NIVVR9M46CM', 'Vincenzo', 'Santoro', '1966-03-28', '3334078752', 'vincenzo.santoro.103@email.com', 70.0, 1.7, 'Via Federico 23', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ9E0HWUQSG2V2AV', 'Gabriele', 'Testa', '1964-04-22', '3331133058', 'gabriele.testa.140@email.com', 70.0, 1.91, 'Via Luigi 38', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZVS87SY4DY89SCD', 'Antonio', 'Palumbo', '2002-08-02', '3334953624', 'antonio.palumbo.59@email.com', 70.0, 1.61, 'Via Anna 76', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUHY1MQNTRQDKUA', 'Giuseppe', 'Martinelli', '1989-11-04', '3335922459', 'giuseppe.martinelli.182@email.com', 70.0, 1.87, 'Via Camilla 81', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZKUS5PVVE8STB4A', 'Sofia', 'Cattaneo', '2003-09-19', '3333758943', 'sofia.cattaneo.180@email.com', 70.0, 1.7, 'Via Giorgia 91', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZJD074BQDB2IJYW', 'Alessandro', 'Bruno', '2002-03-24', '3337616174', 'alessandro.bruno.55@email.com', 70.0, 1.68, 'Via Beatrice 56', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ7GU8Q38US8Z6JG', 'Camilla', 'Greco', '1970-02-07', '3333008605', 'camilla.greco.4@email.com', 70.0, 1.8, 'Via Francesco 7', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZD2P64OLOIY1J2B', 'Giovanni', 'Romano', '1961-02-11', '3332318594', 'giovanni.romano.124@email.com', 70.0, 1.87, 'Via Elena 71', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZZHYMS4V2S2Q5LI', 'Simone', 'Barbieri', '1987-11-27', '3333702441', 'simone.barbieri.172@email.com', 70.0, 1.72, 'Via Valentina 42', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZZGLQ4Q6K4UJ92J', 'Maria', 'Farina', '1969-01-15', '3333948077', 'maria.farina.62@email.com', 70.0, 1.91, 'Via Anna 5', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZKKKQ5W8D5MH8Q0', 'Fabio', 'Romano', '1979-04-26', '3333383060', 'fabio.romano.63@email.com', 70.0, 1.61, 'Via Francesca 62', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZCHS282C9XWI0YA', 'Beatrice', 'Ferrara', '1962-01-07', '3338691558', 'beatrice.ferrara.176@email.com', 120.0, 1.63, 'Via Elena 44', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZMOFPQA9P3RRKDB', 'Sofia', 'Greco', '1972-05-17', '3336636081', 'sofia.greco.189@email.com', 70.0, 1.73, 'Via Nicole 13', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZFZ1XDK4L7WEVIL', 'Vittoria', 'Amato', '1983-02-06', '3336530104', 'vittoria.amato.169@email.com', 70.0, 1.72, 'Via Claudio 60', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMYCOXYZRVKW9SG', 'Maria', 'Riva', '1965-08-22', '3332709206', 'maria.riva.42@email.com', 70.0, 1.64, 'Via Roberto 56', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMQWQZMUHHM9RAF', 'Vincenzo', 'Caruso', '1990-01-14', '3339857892', 'vincenzo.caruso.150@email.com', 70.0, 1.85, 'Via Giuseppe 7', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZC8LNK0WAINTICD', 'Simone', 'Bruno', '1963-04-20', '3338896194', 'simone.bruno.28@email.com', 70.0, 1.84, 'Via Luca 45', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZEUFX2Z8E1G7IMX', 'Elena', 'Villa', '2000-02-09', '3334452429', 'elena.villa.51@email.com', 70.0, 1.86, 'Via Anna 88', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZINQB8SZ8FWZW63', 'Andrea', 'Russo', '1990-07-26', '3338829125', 'andrea.russo.25@email.com', 70.0, 1.92, 'Via Giovanni 31', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZCB8Y9I2VPA7SHE', 'Fabio', 'Farina', '1977-03-17', '3337578390', 'fabio.farina.95@email.com', 70.0, 1.81, 'Via Riccardo 15', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZY6RQ7UBE3U9K78', 'Daniele', 'Testa', '1971-12-08', '3333285849', 'daniele.testa.114@email.com', 70.0, 1.77, 'Via Emma 74', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZGTIKBPYQC31J07', 'Alessia', 'Martini', '1980-10-03', '3335383961', 'alessia.martini.21@email.com', 70.0, 1.9, 'Via Roberto 47', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZY1G07K39V441X6', 'Angelo', 'Conti', '1980-03-05', '3334586675', 'angelo.conti.93@email.com', 70.0, 1.9, 'Via Alessia 77', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ6C18B4N3815DTV', 'Martina', 'Amato', '1972-04-12', '3334641974', 'martina.amato.108@email.com', 70.0, 1.71, 'Via Francesca 33', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ2G37Q8I377R53U', 'Giovanni', 'Lombardi', '1977-10-18', '3338870857', 'giovanni.lombardi.166@email.com', 70.0, 1.63, 'Via Cristina 72', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZIU03I22R7F3C4S', 'Silvia', 'Sanna', '1982-12-07', '3333190866', 'silvia.sanna.13@email.com', 70.0, 1.9, 'Via Antonio 94', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ754E058E5E5899', 'Emma', 'Galli', '1999-04-16', '3334114771', 'emma.galli.111@email.com', 70.0, 1.76, 'Via Beatrice 51', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZR2B756Y2I04746', 'Lorenzo', 'Fontana', '1986-07-06', '3334812351', 'lorenzo.fontana.47@email.com', 70.0, 1.69, 'Via Elena 91', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ58356396956691', 'Giulia', 'Testa', '1984-06-21', '3332407519', 'giulia.testa.68@email.com', 70.0, 1.63, 'Via Francesca 53', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('RSSMRI80A01H501U', 'Mario', 'Speciale', '1980-05-20', '3339999999', 'mario.speciale@mail.it', 80.0, 1.8, 'Via Speciale 1', '2023-01-01', '2023-01-10', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ4K419827431289', 'Ginevra', 'Palumbo', '2001-07-28', '3337920150', 'ginevra.palumbo.10@email.com', 70.0, 1.76, 'Via Simone 89', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ74641551676644', 'Simone', 'Esposito', '1999-01-20', '3339890259', 'simone.esposito.94@email.com', 70.0, 1.83, 'Via Giulia 71', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ214532U08G3787', 'Gabriele', 'Colombo', '1970-07-27', '3333303666', 'gabriele.colombo.136@email.com', 70.0, 1.9, 'Via Roberto 4', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ44933923485816', 'Alessandro', 'Conte', '1999-06-02', '3339943481', 'alessandro.conte.101@email.com', 70.0, 1.78, 'Via Alessia 78', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZK17192N8C9414R', 'Chiara', 'Conte', '1970-05-18', '3333744955', 'chiara.conte.132@email.com', 70.0, 1.91, 'Via Luigi 10', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ03E9N2E4P0083B', 'Stefano', 'Mancini', '1975-01-23', '3334057889', 'stefano.mancini.61@email.com', 70.0, 1.88, 'Via Maria 63', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ91724654924197', 'Giorgia', 'Moretti', '1978-01-16', '3339798485', 'giorgia.moretti.130@email.com', 70.0, 1.79, 'Via Beatrice 22', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZE3K372R4203S9C', 'Salvatore', 'Sanna', '1997-03-01', '3334584218', 'salvatore.sanna.157@email.com', 70.0, 1.85, 'Via Giorgio 37', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ94663831818788', 'Maria', 'Sanna', '1961-04-06', '3334992569', 'maria.sanna.133@email.com', 70.0, 1.74, 'Via Valentina 99', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ15646199343997', 'Giovanni', 'Testa', '1969-02-09', '3332468352', 'giovanni.testa.186@email.com', 70.0, 1.74, 'Via Mattia 47', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZL17J93M01NIO02', 'Luigi', 'Fabbri', '1975-01-20', '3332514330', 'luigi.fabbri.71@email.com', 70.0, 1.83, 'Via Mauro 57', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZY8V6D3Z35C6R1J', 'Aurora', 'Lombardi', '1987-03-23', '3333346581', 'aurora.lombardi.168@email.com', 70.0, 1.63, 'Via Giuseppe 65', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ29699638787346', 'Lorenzo', 'Martinelli', '1987-12-07', '3331908851', 'lorenzo.martinelli.175@email.com', 70.0, 1.63, 'Via Rosario 53', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZY528D69S36214Y', 'Emma', 'Gatti', '1967-12-25', '3335503043', 'emma.gatti.32@email.com', 70.0, 1.84, 'Via Valentina 69', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZM5I51253C49V28', 'Daniele', 'Gallo', '1984-06-18', '3332840590', 'daniele.gallo.8@email.com', 70.0, 1.9, 'Via Francesca 53', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ75553641214811', 'Chiara', 'Gentile', '1994-01-09', '3336687295', 'chiara.gentile.126@email.com', 120.0, 1.83, 'Via Domenico 55', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZZK2B2Q3C591W4C', 'Francesco', 'Pellegrini', '1967-08-27', '3338561138', 'francesco.pellegrini.153@email.com', 70.0, 1.9, 'Via Simona 69', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ11679933182885', 'Sergio', 'Bianco', '1961-07-07', '3336423011', 'sergio.bianco.42@email.com', 70.0, 1.64, 'Via Raffaele 11', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ21473216853757', 'Vittoria', 'Ferri', '1995-11-24', '3334543792', 'vittoria.ferri.133@example.com', 70.0, 1.95, 'Via Ludovica 98', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ6X1X3W3964W08J', 'Ginevra', 'Marchetti', '1969-02-15', '3336302821', 'ginevra.marchetti.150@example.com', 70.0, 1.63, 'Via Mattia 47', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ39762143169733', 'Giorgia', 'Moretti', '1962-09-07', '3336340244', 'giorgia.moretti.87@example.com', 70.0, 1.67, 'Via Ginevra 25', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ91599379597371', 'Giovanni', 'Moretti', '1970-07-16', '3336214619', 'giovanni.moretti.160@example.com', 70.0, 1.69, 'Via Pietro 23', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ26555194917726', 'Anna', 'D''Angelo', '1966-07-28', '3339178978', 'anna.dangelo.187@example.com', 70.0, 1.62, 'Via Sergio 52', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ99324637651794', 'Giulia', 'Lombardi', '1995-10-18', '3333333321', 'giulia.lombardi.153@example.com', 70.0, 1.83, 'Via Davide 73', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ39832267988882', 'Davide', 'De Santis', '1976-11-20', '3337923485', 'davide.de santis.91@example.com', 70.0, 1.77, 'Via Ginevra 7', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ44778151624467', 'Matteo', 'Monti', '1961-09-08', '3335017056', 'matteo.monti.1@example.com', 70.0, 1.84, 'Via Anna 76', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ45543632938887', 'Raffaele', 'Moretti', '1966-03-22', '3336750795', 'raffaele.moretti.98@example.com', 70.0, 1.71, 'Via Arianna 25', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ39185161314811', 'Riccardo', 'Martinelli', '1970-07-16', '3331405096', 'riccardo.martinelli.62@example.com', 70.0, 1.78, 'Via Daniele 90', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ15655762867828', 'Daniele', 'Galli', '1973-10-23', '3336048550', 'daniele.galli.112@example.com', 70.0, 1.83, 'Via Rosario 83', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ31535783359556', 'Gabriele', 'Lombardi', '1967-07-06', '3336906232', 'gabriele.lombardi.198@example.com', 70.0, 1.76, 'Via Massimo 58', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ44975549887752', 'Daniele', 'Fontana', '1972-10-18', '3332766336', 'daniele.fontana.172@example.com', 120.0, 1.9, 'Via Roberto 71', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ58334465839655', 'Roberto', 'De Santis', '1998-05-18', '3331614050', 'roberto.de santis.38@example.com', 70.0, 1.63, 'Via Arianna 90', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ44431936319981', 'Rosario', 'Conte', '1962-09-08', '3331644919', 'rosario.conte.17@example.com', 70.0, 1.77, 'Via Nicola 55', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ42668581781224', 'Angelo', 'Conti', '1967-07-16', '3336961552', 'angelo.conti.95@example.com', 70.0, 1.75, 'Via Claudio 1', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ16776943825832', 'Lorenzo', 'D''Angelo', '1963-01-16', '3336497170', 'lorenzo.dangelo.71@example.com', 70.0, 1.79, 'Via Angelo 83', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ68461715421256', 'Gabriele', 'Marino', '1970-07-27', '3331404118', 'gabriele.marino.146@example.com', 70.0, 1.83, 'Via Rosario 53', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ49117657922758', 'Tommaso', 'De Santis', '1975-02-14', '3337901053', 'tommaso.de santis.152@example.com', 70.0, 1.62, 'Via Roberto 31', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ39758712395565', 'Emma', 'Galli', '1972-10-18', '3336048590', 'emma.galli.33@example.com', 70.0, 1.71, 'Via Luigi 68', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ39497887349133', 'Daniele', 'Bianchi', '1998-05-18', '3338874130', 'daniele.bianchi.28@example.com', 70.0, 1.63, 'Via Pietro 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari');

-- ============================================================
-- DNA  
-- ============================================================
INSERT INTO DNA VALUES
('DNA01','Profilo base','PZE3K372R4203S9C'),
('DNA02','Profilo sport','RSSMRI80A01H501U'),
('DNA03','Profilo clinico','PZA3ZQSTEG6B0M5G');

-- ============================================================
-- GENE  
-- ============================================================
INSERT INTO GENE VALUES
('DNA01','FTO',1,'Metabolismo'),
('DNA02','ACE',1,'Resistenza'),
('DNA03','APOE',1,'Colesterolo');

-- ============================================================
-- RISULTATO TEST GENETICO  
-- ============================================================
INSERT INTO RISULTATO_TEST_GENETICO VALUES
('T01','2023-01-01','2024-01-01','Da approfondire','PZE3K372R4203S9C'),
('T02','2023-01-05','2024-01-05','Esito accettabile','RSSMRI80A01H501U'),
('T03','2023-01-10','2024-01-10','Esito accettabile','PZA3ZQSTEG6B0M5G'),
('T04', '2023-02-01', '2024-02-01', 'Nessuna mutazione rilevante', 'PZK0E1YA8PUJBFK5'),
('T05', '2023-02-15', '2024-02-15', 'Intolleranza al lattosio confermata', 'PZMKWDNKRHT6DQA5'),
('T06', '2023-03-01', '2024-03-01', 'Metabolismo lento dei lipidi', 'PZOGL3EO82JYO6V7'),
('T07', '2023-03-10', '2024-03-10', 'Rischio cardiovascolare medio', 'PZUWMP3ZO345G6EF'),
('T08', '2023-03-20', '2024-03-20', 'Sensibilità alla caffeina', 'PZ3QL2QFKK0RODIN'),
('T09', '2023-04-05', '2024-04-05', 'Carenza vitamina D genetica', 'PZNTRZEAZ46DGEVW'),
('T10', '2023-04-15', '2024-04-15', 'Predisposizione celiachia', 'PZ7SEUDF38G1JE3E'),
('T11', '2023-05-01', '2024-05-01', 'Nessuna anomalia', 'PZK8XYC94RXHAEQX'),
('T12', '2023-05-12', '2024-05-12', 'Profilo ossidativo alterato', 'PZQGZ4IGFF8564MP'),
('T13', '2023-05-25', '2024-05-25', 'Recupero muscolare lento', 'PZW3ALR8K4TNY15Q'),
('T14', '2023-06-01', '2024-06-01', 'Bassa tolleranza ai carboidrati', 'PZRAV4UQU70DOAL7'),
('T15', '2023-06-10', '2024-06-10', 'Metabolismo basale elevato', 'PZ4XTANG7IGCB8U0'),
('T16', '2023-06-20', '2024-06-20', 'Nessuna mutazione rilevante', 'PZCDRUD9Z3JSF1J9'),
('T17', '2023-07-01', '2024-07-01', 'Predisposizione osteoporosi', 'PZIO0M1UKHI1Y6FD'),
('T18', '2023-07-15', '2024-07-15', 'Assorbimento ridotto ferro', 'PZ4WSAT51562WOVH'),
('T19', '2023-07-25', '2024-07-25', 'Sensibilità al sale', 'PZ31ZD24CIXJ19YJ'),
('T20', '2023-08-05', '2024-08-05', 'Nessuna anomalia', 'PZJEK1H5KKM1K4BG'),
('T21', '2023-08-15', '2024-08-15', 'Risposta infiammatoria alta', 'PZ3SLHRNLAYDMAVM'),
('T22', '2023-09-01', '2024-09-01', 'Intolleranza al glutine genetica', 'PZH8ORUS9NGLNQZS'),
('T23', '2023-09-10', '2024-09-10', 'Profilo lipidico a rischio', 'PZV6PP8G1DY6OQCM'),
('T24', '2023-09-20', '2024-09-20', 'Metabolismo lento zuccheri', 'PZRUF8J7824VIDIH'),
('T25', '2023-10-01', '2024-10-01', 'Predisposizione ipertensione', 'PZ1V3BW10RXFHU6X'),
('T26', '2023-10-15', '2024-10-15', 'Nessuna mutazione rilevante', 'PZK786XZX5DVGUUW'),
('T27', '2023-11-01', '2024-11-01', 'Risposta alta allenamento forza', 'PZ8YVWP57KBYF7GA'),
('T28', '2023-11-10', '2024-11-10', 'Metabolizzatore rapido caffeina', 'PZQUOHY9IX8X15CG'),
('T29', '2023-11-20', '2024-11-20', 'Sensibilità insulino-resistenza', 'PZK70HFEEFRRYQUL'),
('T30', '2023-12-05', '2024-12-05', 'Nessuna anomalia', 'PZ7NFBXQHN8N9EH7'),
('T31', '2023-12-15', '2024-12-15', 'Intolleranza fruttosio genetica', 'PZ4LKLR4EGPN2OIV'),
('T32', '2024-01-10', '2025-01-10', 'Elevato fabbisogno antiossidanti', 'PZT5WPB80UJZEFWT'),
('T33', '2024-01-20', '2025-01-20', 'Predisposizione infortuni tendinei', 'PZDD8P69T4RJ6GEG'),
('T34', '2024-02-01', '2025-02-01', 'Sensibilità agli zuccheri raffinati', 'PZXRA0AMIOH9TISL'),
('T35', '2024-02-15', '2025-02-15', 'Metabolismo caffeina lento', 'PZKWUVPVN3KM9HF7'),
('T36', '2024-03-01', '2025-03-01', 'Nessuna mutazione rilevante', 'PZBRZC9J7HPZDAG1'),
('T37', '2024-03-10', '2025-03-10', 'Predisposizione genetica obesità', 'PZNUD1EA1R75M69C'),
('T38', '2024-03-20', '2025-03-20', 'Necessità integrazione Omega-3', 'PZ312WHL7TEV3TLW'),
('T39', '2024-04-05', '2025-04-05', 'Profilo infiammatorio basso', 'PZ7GHWWJAMT27CYB'),
('T40', '2024-04-15', '2025-04-15', 'Intolleranza istamina genetica', 'PZYLPWACIQXST8AY'),
('T41', '2024-05-01', '2025-05-01', 'Rischio carenza ferro', 'PZ1STXPBCZ6MEV18'),
('T42', '2024-05-12', '2025-05-12', 'Nessuna anomalia', 'PZZ0ELPJV2WHYMHA'),
('T43', '2024-05-25', '2025-05-25', 'Metabolismo veloce dei lipidi', 'PZI5KO0F6BOMPH40'),
('T44', '2023-01-10', '2024-01-10', 'Metabolismo lento caffeina', 'PZIEL3MDXQ48LT2K'),
('T45', '2023-01-15', '2024-01-15', 'Intolleranza lattosio', 'PZXWYX0G1AJFR3CL'),
('T46', '2023-01-20', '2024-01-20', 'Rischio infortuni legamenti', 'PZIH8EYYULL9FU7V'),
('T47', '2023-01-25', '2024-01-25', 'Nessuna anomalia rilevata', 'PZ6RUBM41Q32XV6L'),
('T48', '2023-02-01', '2024-02-01', 'Sensibilità al sale', 'PZ4JLJDKE7L7ZVDZ'),
('T49', '2023-02-05', '2024-02-05', 'Metabolismo veloce carboidrati', 'PZQAQBOZUW37HYM8'),
('T50', '2023-02-10', '2024-02-10', 'Carenza vitamina B12 genetica', 'PZVQZSL3C8GV7M2G'),
('T51', '2023-02-15', '2024-02-15', 'Profilo infiammatorio alto', 'PZR61JQXYXYTTRP6'),
('T52', '2023-02-20', '2024-02-20', 'Predisposizione celiachia', 'PZ69F9OCTSL8OQKV'),
('T53', '2023-02-25', '2024-02-25', 'Nessuna anomalia', 'PZYQT7RWBNYHZE0C'),
('T54', '2023-03-01', '2024-03-01', 'Rischio osteoporosi', 'PZVFBOA5BAD9UJK1'),
('T55', '2023-03-05', '2024-03-05', 'Recupero post-allenamento lento', 'PZR3CY9C8EB13KZ4'),
('T56', '2023-03-10', '2024-03-10', 'Metabolismo lipidi alterato', 'PZVCX9G4IUP4R06Q'),
('T57', '2023-03-15', '2024-03-15', 'Sensibilità insulino-resistenza', 'PZYJ0TQI50ZJ6WH1'),
('T58', '2023-03-20', '2024-03-20', 'Nessuna mutazione rilevante', 'PZF794JBKJOLW3BI'),
('T59', '2023-03-25', '2024-03-25', 'Intolleranza fruttosio', 'PZLVJZ587CRUSAEU'),
('T60', '2023-04-01', '2024-04-01', 'Fabbisogno aumentato folati', 'PZI3C0F1E0RZ6MMR'),
('T61', '2023-04-05', '2024-04-05', 'Risposta alta allenamento forza', 'PZ1YPQ82S3XXZAGM'),
('T62', '2023-04-10', '2024-04-10', 'Metabolizzatore rapido farmaci', 'PZWJ8N9FE2Y5UKXZ'),
('T63', '2023-04-15', '2024-04-15', 'Nessuna anomalia', 'PZTMV9635PXNIJUY'),
('T64', '2023-04-20', '2024-04-20', 'Stress ossidativo elevato', 'PZ6UHYJF9EOF24WY'),
('T65', '2023-04-25', '2024-04-25', 'Predisposizione obesità', 'PZ7RQIF7A3YOA6YE'),
('T66', '2023-05-01', '2024-05-01', 'Sensibilità glutine non celiaca', 'PZH0ROQ8DRAKNSYR'),
('T67', '2023-05-05', '2024-05-05', 'Metabolismo basale ridotto', 'PZ2O11ZTHSGRZKRR'),
('T68', '2023-05-10', '2024-05-10', 'Nessuna anomalia rilevata', 'PZFX6BNDY6FQ0UCB'),
('T69', '2023-05-15', '2024-05-15', 'Rischio ridotto infortuni', 'PZ3TJWIOA9FJFP0A'),
('T70', '2023-05-20', '2024-05-20', 'Carenza vitamina D', 'PZMQ5MHLHCZJHVHN'),
('T71', '2023-05-25', '2024-05-25', 'Metabolismo zuccheri efficiente', 'PZTMWTBH8RTVH0QC'),
('T72', '2023-06-01', '2024-06-01', 'Intolleranza istamina', 'PZB57F2AI0GI0PQM'),
('T73', '2023-06-05', '2024-06-05', 'Nessuna mutazione', 'PZUVKALVZ27GSXAA'),
('T74', '2023-06-10', '2024-06-10', 'Profilo lipidico ottimale', 'PZOZ7HG512ZGQUK6'),
('T75', '2023-06-15', '2024-06-15', 'Rischio ipertensione sale-sensibile', 'PZ8FNF7XVOJQKIGG'),
('T76', '2023-06-20', '2024-06-20', 'Recupero muscolare rapido', 'PZMUYSE7FA5FUDCU'),
('T77', '2023-06-25', '2024-06-25', 'Necessità omega-3 aumentata', 'PZBQXZRGTO4MG63I'),
('T78', '2023-07-01', '2024-07-01', 'Nessuna anomalia', 'PZ3VDG2QXF5NIXE5'),
('T79', '2023-07-05', '2024-07-05', 'Intolleranza lattosio secondaria', 'PZJDGG5W0YN7UE1B'),
('T80', '2023-07-10', '2024-07-10', 'Metabolismo alcool lento', 'PZ6CANCTO9JNOXJU'),
('T81', '2023-07-15', '2024-07-15', 'Predisposizione diabete tipo 2', 'PZW5BOU47891JX3M'),
('T82', '2023-07-20', '2024-07-20', 'Risposta infiammatoria bassa', 'PZWHG5S5IHP593GO'),
('T83', '2023-07-25', '2024-07-25', 'Nessuna mutazione rilevante', 'PZ954OPOO8TS3462'),
('T84', '2023-08-01', '2024-08-01', 'Metabolismo caffeina rapido', 'PZFF7KS1SUILY6K9'),
('T85', '2023-08-05', '2024-08-05', 'Sensibilità carboidrati raffinati', 'PZ8HGVM1JSM7CF2F'),
('T86', '2023-08-10', '2024-08-10', 'Rischio tendinopatie', 'PZQOND7F3URO7PT3'),
('T87', '2023-08-15', '2024-08-15', 'Assorbimento ferro alterato', 'PZNSM2B991EWV5C1'),
('T88', '2023-08-20', '2024-08-20', 'Nessuna anomalia', 'PZW0DATQ3LVQI8X6'),
('T89', '2023-08-25', '2024-08-25', 'Metabolismo lipidi lento', 'PZUU0LGQPKJ2CKJV'),
('T90', '2023-09-01', '2024-09-01', 'Intolleranza solfiti', 'PZUTG0WWX4JZKYSS'),
('T91', '2023-09-05', '2024-09-05', 'Capacità detossificante ridotta', 'PZMKLE6733MYEW0X'),
('T92', '2023-09-10', '2024-09-10', 'Fabbisogno proteico elevato', 'PZ4UPYZIPTO985J4'),
('T93', '2023-09-15', '2024-09-15', 'Nessuna mutazione', 'PZB29909C4QEWU9Z'),
('T94', '2023-09-20', '2024-09-20', 'Rischio obesità addominale', 'PZFRHJ35HTT1J8OO'),
('T95', '2023-09-25', '2024-09-25', 'Metabolismo basale molto alto', 'PZA3ZQSTEG6B0M5G'),
('T96', '2023-10-01', '2024-10-01', 'Intolleranza lattosio genetica', 'PZU5701OF2CMBZDO'),
('T97', '2023-10-05', '2024-10-05', 'Nessuna anomalia rilevata', 'PZFCWLQTIEN35N5C'),
('T98', '2023-10-10', '2024-10-10', 'Predisposizione carenza calcio', 'PZJAKZ75W2P0LO3S'),
('T99', '2023-10-15', '2024-10-15', 'Sensibilità alta ai carboidrati', 'PZ57T80QHTB7TE17'),
('T100', '2023-10-20', '2024-10-20', 'Rischio infiammazione cronica', 'PZUG2IHTC7ANPL3R'),
('T101', '2023-10-25', '2024-10-25', 'Metabolismo lento caffeina', 'PZBJU4KL3T2KBUMU'),
('T102', '2023-11-01', '2024-11-01', 'Nessuna mutazione significativa', 'PZK50NIVVR9M46CM'),
('T103', '2023-11-05', '2024-11-05', 'Profilo di recupero rapido', 'PZ9E0HWUQSG2V2AV'),
('T104', '2023-11-10', '2024-11-10', 'Necessità antiossidanti aumentata', 'PZVS87SY4DY89SCD'),
('T105', '2023-11-15', '2024-11-15', 'Intolleranza glutine genetica', 'PZUHY1MQNTRQDKUA'),
('T106', '2023-11-20', '2024-11-20', 'Rischio infortuni muscolari', 'PZKUS5PVVE8STB4A'),
('T107', '2023-11-25', '2024-11-25', 'Metabolismo lipidi efficiente', 'PZJD074BQDB2IJYW'),
('T108', '2023-12-01', '2024-12-01', 'Sensibilità sodio elevata', 'PZ7GU8Q38US8Z6JG'),
('T109', '2023-12-05', '2024-12-05', 'Predisposizione diabete 2', 'PZD2P64OLOIY1J2B'),
('T110', '2023-12-10', '2024-12-10', 'Nessuna anomalia', 'PZZHYMS4V2S2Q5LI'),
('T111', '2023-12-15', '2024-12-15', 'Carenza vitamina B6', 'PZZGLQ4Q6K4UJ92J'),
('T112', '2023-12-20', '2024-12-20', 'Profilo ormonale a rischio', 'PZKKKQ5W8D5MH8Q0'),
('T113', '2023-12-25', '2024-12-25', 'Intolleranza lattosio', 'PZCHS282C9XWI0YA'),
('T114', '2024-01-05', '2025-01-05', 'Metabolismo zuccheri lento', 'PZMOFPQA9P3RRKDB'),
('T115', '2024-01-10', '2025-01-10', 'Rischio osteoporosi precoce', 'PZFZ1XDK4L7WEVIL'),
('T116', '2024-01-15', '2025-01-15', 'Nessuna mutazione', 'PZMYCOXYZRVKW9SG'),
('T117', '2024-01-20', '2025-01-20', 'Sensibilità alcool elevata', 'PZMQWQZMUHHM9RAF'),
('T118', '2024-01-25', '2025-01-25', 'Fabbisogno aumentato Omega-3', 'PZC8LNK0WAINTICD'),
('T119', '2024-02-01', '2025-02-01', 'Stress ossidativo alto', 'PZEUFX2Z8E1G7IMX'),
('T120', '2024-02-05', '2025-02-05', 'Predisposizione celiachia', 'PZINQB8SZ8FWZW63'),
('T121', '2024-02-10', '2025-02-10', 'Metabolismo basale basso', 'PZCB8Y9I2VPA7SHE'),
('T122', '2024-02-15', '2025-02-15', 'Rischio cardiovascolare', 'PZY6RQ7UBE3U9K78'),
('T123', '2024-02-20', '2025-02-20', 'Nessuna anomalia rilevata', 'PZGTIKBPYQC31J07'),
('T124', '2024-02-25', '2025-02-25', 'Intolleranza fruttosio', 'PZY1G07K39V441X6'),
('T125', '2024-03-01', '2025-03-01', 'Risposta infiammatoria alta', 'PZ6C18B4N3815DTV'),
('T126', '2024-03-05', '2025-03-05', 'Metabolismo caffeina rapido', 'PZ2G37Q8I377R53U'),
('T127', '2024-03-10', '2025-03-10', 'Sensibilità insulino-resistenza', 'PZIU03I22R7F3C4S'),
('T128', '2024-03-15', '2025-03-15', 'Carenza ferro genetica', 'PZ754E058E5E5899'),
('T129', '2024-03-20', '2025-03-20', 'Nessuna mutazione', 'PZR2B756Y2I04746'),
('T130', '2024-03-25', '2025-03-25', 'Rischio infortuni legamenti', 'PZ58356396956691'),
('T131', '2024-04-01', '2025-04-01', 'Intolleranza lattosio secondaria', 'RSSMRI80A01H501U'),
('T132', '2024-04-05', '2025-04-05', 'Metabolismo lipidi alterato', 'PZ4K419827431289'),
('T133', '2024-04-10', '2025-04-10', 'Predisposizione obesità', 'PZ74641551676644'),
('T134', '2024-04-15', '2025-04-15', 'Fabbisogno folati aumentato', 'PZ214532U08G3787'),
('T135', '2024-04-20', '2025-04-20', 'Nessuna anomalia rilevata', 'PZ44933923485816'),
('T136', '2024-04-25', '2025-04-25', 'Sensibilità ai carboidrati', 'PZK17192N8C9414R'),
('T137', '2024-05-01', '2025-05-01', 'Rischio ipertensione', 'PZ03E9N2E4P0083B'),
('T138', '2024-05-05', '2025-05-05', 'Recupero muscolare lento', 'PZ91724654924197'),
('T139', '2024-05-10', '2025-05-10', 'Carenza vitamina D', 'PZE3K372R4203S9C'),
('T140', '2024-05-15', '2025-05-15', 'Metabolismo lento', 'PZ94663831818788'),
('T141', '2024-05-20', '2025-05-20', 'Intolleranza istamina', 'PZ15646199343997'),
('T142', '2024-05-25', '2025-05-25', 'Nessuna anomalia', 'PZL17J93M01NIO02'),
('T143', '2024-06-01', '2025-06-01', 'Rischio sindrome metabolica', 'PZY8V6D3Z35C6R1J'),
('T144', '2024-06-05', '2025-06-05', 'Sensibilità zuccheri elevata', 'PZ29699638787346'),
('T145', '2024-06-10', '2025-06-10', 'Nessuna mutazione rilevante', 'PZY528D69S36214Y'),
('T146', '2024-06-15', '2025-06-15', 'Metabolismo lento lipidi', 'PZM5I51253C49V28'),
('T147', '2024-06-20', '2025-06-20', 'Predisposizione celiachia', 'PZ75553641214811'),
('T148', '2024-06-25', '2025-06-25', 'Rischio infortuni tendinei', 'PZZK2B2Q3C591W4C'),
('T149', '2024-07-01', '2025-07-01', 'Nessuna anomalia', 'PZ11679933182885'),
('T150', '2024-07-05', '2025-07-05', 'Intolleranza lattosio', 'PZ21473216853757'),
('T151', '2024-07-10', '2025-07-10', 'Metabolismo caffeina lento', 'PZ6X1X3W3964W08J'),
('T152', '2024-07-15', '2025-07-15', 'Profilo infiammatorio alto', 'PZ39762143169733'),
('T153', '2024-07-20', '2025-07-20', 'Sensibilità glutine non celiaca', 'PZ91599379597371'),
('T154', '2024-07-25', '2025-07-25', 'Nessuna mutazione', 'PZ26555194917726'),
('T155', '2024-08-01', '2025-08-01', 'Rischio cardiovascolare medio', 'PZ99324637651794'),
('T156', '2024-08-05', '2025-08-05', 'Metabolismo zuccheri rapido', 'PZ39832267988882'),
('T157', '2024-08-10', '2025-08-10', 'Carenza vitamina B12', 'PZ44778151624467'),
('T158', '2024-08-15', '2025-08-15', 'Nessuna anomalia rilevata', 'PZ45543632938887'),
('T159', '2024-08-20', '2025-08-20', 'Predisposizione obesità', 'PZ39185161314811'),
('T160', '2024-08-25', '2025-08-25', 'Stress ossidativo elevato', 'PZ15655762867828'),
('T161', '2024-09-01', '2025-09-01', 'Recupero muscolare lento', 'PZ31535783359556'),
('T162', '2024-09-05', '2025-09-05', 'Intolleranza istamina', 'PZ44975549887752'),
('T163', '2024-09-10', '2025-09-10', 'Nessuna mutazione rilevante', 'PZ58334465839655'),
('T164', '2024-09-15', '2025-09-15', 'Metabolismo basale ridotto', 'PZ44431936319981'),
('T165', '2024-09-20', '2025-09-20', 'Sensibilità sale', 'PZ42668581781224'),
('T166', '2024-09-25', '2025-09-25', 'Fabbisogno aumentato folati', 'PZ16776943825832'),
('T167', '2024-10-01', '2025-10-01', 'Nessuna anomalia', 'PZ68461715421256'),
('T168', '2024-10-05', '2025-10-05', 'Rischio sindrome metabolica', 'PZ49117657922758'),
('T169', '2024-10-10', '2025-10-10', 'Predisposizione infortuni', 'PZ39758712395565'),
('T170', '2024-10-15', '2025-10-15', 'Metabolismo lipidi efficiente', 'PZ39497887349133'),
('T171', '2024-11-01', '2025-11-01', 'Miglioramento parametri infiammatori', 'PZK0E1YA8PUJBFK5'),
('T172', '2024-11-05', '2025-11-05', 'Intolleranza lattosio persistente', 'PZMKWDNKRHT6DQA5'),
('T173', '2024-11-10', '2025-11-10', 'Metabolismo lipidi stabile', 'PZOGL3EO82JYO6V7'),
('T174', '2024-11-15', '2025-11-15', 'Rischio cardiovascolare ridotto', 'PZUWMP3ZO345G6EF'),
('T175', '2024-11-20', '2025-11-20', 'Sensibilità caffeina confermata', 'PZ3QL2QFKK0RODIN'),
('T176', '2024-11-25', '2025-11-25', 'Livelli vitamina D normalizzati', 'PZNTRZEAZ46DGEVW'),
('T177', '2024-12-01', '2025-12-01', 'Marker celiachia negativi', 'PZ7SEUDF38G1JE3E'),
('T178', '2024-12-05', '2025-12-05', 'Nessuna nuova anomalia', 'PZK8XYC94RXHAEQX'),
('T179', '2024-12-10', '2025-12-10', 'Stress ossidativo migliorato', 'PZQGZ4IGFF8564MP'),
('T180', '2024-12-15', '2025-12-15', 'Recupero muscolare migliorato', 'PZW3ALR8K4TNY15Q'),
('T181', '2025-01-05', '2026-01-05', 'Tolleranza carboidrati invariata', 'PZRAV4UQU70DOAL7'),
('T182', '2025-01-10', '2026-01-10', 'Metabolismo basale attivo', 'PZ4XTANG7IGCB8U0'),
('T183', '2025-01-15', '2026-01-15', 'Screening routine negativo', 'PZCDRUD9Z3JSF1J9'),
('T184', '2025-01-20', '2026-01-20', 'Densità ossea monitorata', 'PZIO0M1UKHI1Y6FD'),
('T185', '2025-01-25', '2026-01-25', 'Assorbimento ferro stabile', 'PZ4WSAT51562WOVH'),
('T186', '2025-02-01', '2026-02-01', 'Sensibilità sale ridotta', 'PZ31ZD24CIXJ19YJ'),
('T187', '2025-02-05', '2026-02-05', 'Checkup annuale ok', 'PZJEK1H5KKM1K4BG'),
('T188', '2025-02-10', '2026-02-10', 'Risposta infiammatoria sotto controllo', 'PZ3SLHRNLAYDMAVM'),
('T189', '2025-02-15', '2026-02-15', 'Intolleranza glutine confermata', 'PZH8ORUS9NGLNQZS'),
('T190', '2025-02-20', '2026-02-20', 'Profilo lipidico migliorato', 'PZV6PP8G1DY6OQCM'),
('T191', '2025-03-01', '2026-03-01', 'Metabolismo zuccheri stabile', 'PZRUF8J7824VIDIH'),
('T192', '2025-03-05', '2026-03-05', 'Pressione arteriosa genetica ok', 'PZ1V3BW10RXFHU6X'),
('T193', '2025-03-10', '2026-03-10', 'Nessuna variazione genetica', 'PZK786XZX5DVGUUW'),
('T194', '2025-03-15', '2026-03-15', 'Risposta ipertrofica elevata', 'PZ8YVWP57KBYF7GA'),
('T195', '2025-03-20', '2026-03-20', 'Metabolismo lento caffeina', 'PZQUOHY9IX8X15CG'),
('T196', '2025-03-25', '2026-03-25', 'Sensibilità zuccheri ridotta', 'PZK70HFEEFRRYQUL'),
('T197', '2025-04-01', '2026-04-01', 'Nessuna anomalia significativa', 'PZ7NFBXQHN8N9EH7'),
('T198', '2025-04-05', '2026-04-05', 'Intolleranza fruttosio confermata', 'PZ4LKLR4EGPN2OIV'),
('T199', '2025-04-10', '2026-04-10', 'Fabbisogno antiossidanti alto', 'PZT5WPB80UJZEFWT'),
('T200', '2025-04-15', '2026-04-15', 'Rischio infiammazione tendinea', 'PZDD8P69T4RJ6GEG'),
('T201', '2025-04-20', '2026-04-20', 'Sensibilità carboidrati', 'PZXRA0AMIOH9TISL'),
('T202', '2025-04-25', '2026-04-25', 'Metabolismo farmaci lento', 'PZKWUVPVN3KM9HF7'),
('T203', '2025-05-01', '2026-05-01', 'Nessuna mutazione rilevante', 'PZBRZC9J7HPZDAG1'),
('T204', '2025-05-05', '2026-05-05', 'Predisposizione sovrappeso', 'PZNUD1EA1R75M69C'),
('T205', '2025-05-10', '2026-05-10', 'Necessità integrazione Omega-3', 'PZ312WHL7TEV3TLW'),
('T206', '2025-05-15', '2026-05-15', 'Profilo infiammatorio basso', 'PZ7GHWWJAMT27CYB'),
('T207', '2025-05-20', '2026-05-20', 'Intolleranza istamina', 'PZYLPWACIQXST8AY'),
('T208', '2025-05-25', '2026-05-25', 'Rischio anemia genetica', 'PZ1STXPBCZ6MEV18'),
('T209', '2025-06-01', '2026-06-01', 'Nessuna anomalia', 'PZZ0ELPJV2WHYMHA'),
('T210', '2025-06-05', '2026-06-05', 'Metabolismo lipidi veloce', 'PZI5KO0F6BOMPH40'),
('T211', '2025-06-10', '2026-06-10', 'Sensibilità caffeina moderata', 'PZIEL3MDXQ48LT2K'),
('T212', '2025-06-15', '2026-06-15', 'Intolleranza lattosio', 'PZXWYX0G1AJFR3CL'),
('T213', '2025-06-20', '2026-06-20', 'Rischio legamenti', 'PZIH8EYYULL9FU7V'),
('T214', '2025-06-25', '2026-06-25', 'Nessuna anomalia rilevata', 'PZ6RUBM41Q32XV6L'),
('T215', '2025-07-01', '2026-07-01', 'Ipertensione sale-sensibile', 'PZ4JLJDKE7L7ZVDZ'),
('T216', '2025-07-05', '2026-07-05', 'Metabolismo carboidrati efficiente', 'PZQAQBOZUW37HYM8'),
('T217', '2025-07-10', '2026-07-10', 'Carenza B12 genetica', 'PZVQZSL3C8GV7M2G'),
('T218', '2025-07-15', '2026-07-15', 'Marker infiammatori alti', 'PZR61JQXYXYTTRP6'),
('T219', '2025-07-20', '2026-07-20', 'Predisposizione celiachia', 'PZ69F9OCTSL8OQKV'),
('T220', '2025-07-25', '2026-07-25', 'Nessuna anomalia', 'PZYQT7RWBNYHZE0C'),
('T221', '2025-08-01', '2026-08-01', 'Rischio debolezza ossea', 'PZVFBOA5BAD9UJK1'),
('T222', '2025-08-05', '2026-08-05', 'Recupero post-workout lento', 'PZR3CY9C8EB13KZ4'),
('T223', '2025-08-10', '2026-08-10', 'Metabolismo lipidi alterato', 'PZVCX9G4IUP4R06Q'),
('T224', '2025-08-15', '2026-08-15', 'Insulino-resistenza genetica', 'PZYJ0TQI50ZJ6WH1'),
('T225', '2025-08-20', '2026-08-20', 'Nessuna mutazione significativa', 'PZF794JBKJOLW3BI'),
('T226', '2025-08-25', '2026-08-25', 'Intolleranza fruttosio', 'PZLVJZ587CRUSAEU'),
('T227', '2025-09-01', '2026-09-01', 'Fabbisogno folati alto', 'PZI3C0F1E0RZ6MMR'),
('T228', '2025-09-05', '2026-09-05', 'Risposta allenamento forza alta', 'PZ1YPQ82S3XXZAGM'),
('T229', '2025-09-10', '2026-09-10', 'Metabolismo lento farmaci', 'PZWJ8N9FE2Y5UKXZ'),
('T230', '2025-09-15', '2026-09-15', 'Nessuna anomalia', 'PZTMV9635PXNIJUY'),
('T231', '2025-09-20', '2026-09-20', 'Stress ossidativo alto', 'PZ6UHYJF9EOF24WY'),
('T232', '2025-09-25', '2026-09-25', 'Predisposizione obesità addominale', 'PZ7RQIF7A3YOA6YE'),
('T233', '2025-10-01', '2026-10-01', 'Sensibilità glutine', 'PZH0ROQ8DRAKNSYR'),
('T234', '2025-10-05', '2026-10-05', 'Metabolismo basale lento', 'PZ2O11ZTHSGRZKRR'),
('T235', '2025-10-10', '2026-10-10', 'Nessuna mutazione rilevante', 'PZFX6BNDY6FQ0UCB'),
('T236', '2025-10-15', '2026-10-15', 'Basso rischio infortuni', 'PZ3TJWIOA9FJFP0A'),
('T237', '2025-10-20', '2026-10-20', 'Carenza vitamina D', 'PZMQ5MHLHCZJHVHN'),
('T238', '2025-10-25', '2026-10-25', 'Metabolismo zuccheri efficace', 'PZTMWTBH8RTVH0QC'),
('T239', '2025-11-01', '2026-11-01', 'Intolleranza istamina', 'PZB57F2AI0GI0PQM'),
('T240', '2025-11-05', '2026-11-05', 'Nessuna mutazione', 'PZUVKALVZ27GSXAA'),
('T241', '2025-11-10', '2026-11-10', 'Profilo lipidico buono', 'PZOZ7HG512ZGQUK6'),
('T242', '2025-11-15', '2026-11-15', 'Sensibilità sale elevata', 'PZ8FNF7XVOJQKIGG'),
('T243', '2025-11-20', '2026-11-20', 'Recupero muscolare veloce', 'PZMUYSE7FA5FUDCU'), 
('T244', '2025-11-25', '2026-11-25', 'Necessità integrazione Omega-3', 'PZBQXZRGTO4MG63I'),
('T245', '2025-12-01', '2026-12-01', 'Nessuna anomalia rilevata', 'PZ3VDG2QXF5NIXE5'),
('T246', '2025-12-05', '2026-12-05', 'Intolleranza lattosio', 'PZJDGG5W0YN7UE1B'),
('T247', '2025-12-10', '2026-12-10', 'Metabolismo alcool lento', 'PZ6CANCTO9JNOXJU'),
('T248', '2025-12-15', '2026-12-15', 'Predisposizione diabete 2', 'PZW5BOU47891JX3M'),
('T249', '2025-12-20', '2026-12-20', 'Risposta infiammatoria bassa', 'PZWHG5S5IHP593GO'),
('T250', '2025-12-25', '2026-12-25', 'Nessuna mutazione significativa', 'PZ954OPOO8TS3462'),
('T251', '2026-01-05', '2027-01-05', 'Metabolismo caffeina rapido', 'PZFF7KS1SUILY6K9'),
('T252', '2026-01-10', '2027-01-10', 'Sensibilità carboidrati', 'PZ8HGVM1JSM7CF2F'),
('T253', '2026-01-15', '2027-01-15', 'Rischio tendinopatie', 'PZQOND7F3URO7PT3'),
('T254', '2026-01-20', '2027-01-20', 'Assorbimento ferro alterato', 'PZNSM2B991EWV5C1'),
('T255', '2026-01-25', '2027-01-25', 'Nessuna anomalia', 'PZW0DATQ3LVQI8X6'),
('T256', '2026-02-01', '2027-02-01', 'Metabolismo lipidi lento', 'PZUU0LGQPKJ2CKJV'),
('T257', '2026-02-05', '2027-02-05', 'Intolleranza solfiti', 'PZUTG0WWX4JZKYSS'),
('T258', '2026-02-10', '2027-02-10', 'Capacità detossificante ridotta', 'PZMKLE6733MYEW0X'),
('T259', '2026-02-15', '2027-02-15', 'Fabbisogno proteico elevato', 'PZ4UPYZIPTO985J4'),
('T260', '2026-02-20', '2027-02-20', 'Nessuna mutazione', 'PZB29909C4QEWU9Z'),
('T261', '2026-02-25', '2027-02-25', 'Rischio obesità addominale', 'PZFRHJ35HTT1J8OO'),
('T262', '2026-03-01', '2027-03-01', 'Metabolismo basale alto', 'PZA3ZQSTEG6B0M5G'),
('T263', '2026-03-05', '2027-03-05', 'Intolleranza lattosio', 'PZU5701OF2CMBZDO'),
('T264', '2026-03-10', '2027-03-10', 'Nessuna anomalia rilevata', 'PZFCWLQTIEN35N5C'),
('T265', '2026-03-15', '2027-03-15', 'Predisposizione carenza calcio', 'PZJAKZ75W2P0LO3S'),
('T266', '2026-03-20', '2027-03-20', 'Sensibilità carboidrati alta', 'PZ57T80QHTB7TE17'),
('T267', '2026-03-25', '2027-03-25', 'Rischio infiammazione cronica', 'PZUG2IHTC7ANPL3R'),
('T268', '2026-04-01', '2027-04-01', 'Metabolismo lento caffeina', 'PZBJU4KL3T2KBUMU'),
('T269', '2026-04-05', '2027-04-05', 'Nessuna mutazione significativa', 'PZK50NIVVR9M46CM'),
('T270', '2026-04-10', '2027-04-10', 'Recupero rapido confermato', 'PZ9E0HWUQSG2V2AV'),
('T271', '2026-04-15', '2027-04-15', 'Parametri infiammatori normalizzati', 'PZK0E1YA8PUJBFK5'),
('T272', '2026-04-20', '2027-04-20', 'Tolleranza lattosio peggiorata', 'PZMKWDNKRHT6DQA5'),
('T273', '2026-04-25', '2027-04-25', 'Metabolismo lipidi migliorato', 'PZOGL3EO82JYO6V7'),
('T274', '2026-05-01', '2027-05-01', 'Rischio cardiovascolare stabile', 'PZUWMP3ZO345G6EF'),
('T275', '2026-05-05', '2027-05-05', 'Sensibilità caffeina invariata', 'PZ3QL2QFKK0RODIN'),
('T276', '2026-05-10', '2027-05-10', 'Livelli vitamina D ottimali', 'PZNTRZEAZ46DGEVW'),
('T277', '2026-05-15', '2027-05-15', 'Nessuna nuova intolleranza', 'PZ7SEUDF38G1JE3E'),
('T278', '2026-05-20', '2027-05-20', 'Profilo genetico confermato stabile', 'PZK8XYC94RXHAEQX'),
('T279', '2026-05-25', '2027-05-25', 'Stress ossidativo nella norma', 'PZQGZ4IGFF8564MP'),
('T280', '2026-06-01', '2027-06-01', 'Recupero muscolare eccellente', 'PZW3ALR8K4TNY15Q'),
('T281', '2026-06-05', '2027-06-05', 'Tolleranza carboidrati migliorata', 'PZRAV4UQU70DOAL7'),
('T282', '2026-06-10', '2027-06-10', 'Metabolismo basale stabile', 'PZ4XTANG7IGCB8U0'),
('T283', '2026-06-15', '2027-06-15', 'Screening annuale negativo', 'PZCDRUD9Z3JSF1J9'),
('T284', '2026-06-20', '2027-06-20', 'Salute ossea preservata', 'PZIO0M1UKHI1Y6FD'),
('T285', '2026-06-25', '2027-06-25', 'Assorbimento ferro migliorato', 'PZ4WSAT51562WOVH'),
('T286', '2026-07-01', '2027-07-01', 'Sensibilità sale monitorata', 'PZ31ZD24CIXJ19YJ'),
('T287', '2026-07-05', '2027-07-05', 'Checkup genetico periodico ok', 'PZJEK1H5KKM1K4BG'),
('T288', '2026-07-10', '2027-07-10', 'Risposta infiammatoria bassa', 'PZ3SLHRNLAYDMAVM'),
('T289', '2026-07-15', '2027-07-15', 'Gestione glutine ottimizzata', 'PZH8ORUS9NGLNQZS'),
('T290', '2026-07-20', '2027-07-20', 'Profilo lipidico eccellente', 'PZV6PP8G1DY6OQCM'),
('T291', '2026-07-25', '2027-07-25', 'Metabolismo zuccheri invariato', 'PZRUF8J7824VIDIH'),
('T292', '2026-08-01', '2027-08-01', 'Pressione arteriosa stabile', 'PZ1V3BW10RXFHU6X'),
('T293', '2026-08-05', '2027-08-05', 'Nessuna variazione rilevata', 'PZK786XZX5DVGUUW'),
('T294', '2026-08-10', '2027-08-10', 'Risposta allenamento forza costante', 'PZ8YVWP57KBYF7GA'),
('T295', '2026-08-15', '2027-08-15', 'Metabolismo caffeina invariato', 'PZQUOHY9IX8X15CG'),
('T296', '2026-08-20', '2027-08-20', 'Sensibilità zuccheri controllata', 'PZK70HFEEFRRYQUL'),
('T297', '2026-08-25', '2027-08-25', 'Nessuna nuova anomalia', 'PZ7NFBXQHN8N9EH7'),
('T298', '2026-09-01', '2027-09-01', 'Intolleranza fruttosio gestita', 'PZ4LKLR4EGPN2OIV'),
('T299', '2026-09-05', '2027-09-05', 'Antiossidanti nella norma', 'PZT5WPB80UJZEFWT'),
('T300', '2026-09-10', '2027-09-10', 'Salute tendinea preservata', 'PZDD8P69T4RJ6GEG');

-- ============================================================
-- REPORT 
-- ============================================================
INSERT INTO REPORT VALUES
('R01','MDCRSS80A01F205X','2023-02-01','Buono'),
('R02','MDCBNCH75B02F205','2023-02-05','Ottimo'),
('R03','MDCLVR82C03F205Z','2023-02-10','Regolare');

-- ============================================================
-- DERIVAZIONE  
-- ============================================================
INSERT INTO DERIVAZIONE VALUES
('MDCRSS80A01F205X','R01','T01'),
('MDCBNCH75B02F205','R02','T02'),
('MDCLVR82C03F205Z','R03','T03');

-- ============================================================
-- PIANO_DIETA (3 – no sovrapposizioni)
-- ============================================================
INSERT INTO PIANO_DIETA VALUES
('PZE3K372R4203S9C','Piano1','2023-02-10',NULL,'Mediterranea','1.0'),
('RSSMRI80A01H501U','Piano2','2023-02-15',NULL,'Chetogenica','1.0'),
('PZA3ZQSTEG6B0M5G','Piano3','2023-02-20',NULL,'Sportiva','1.0'),
('PZK0E1YA8PUJBFK5', 'Piano Dimagrimento 2023', '2023-03-01', NULL, 'Mediterranea', '1.0'),
('PZMKWDNKRHT6DQA5', 'Piano Massa Muscolare', '2023-03-05', NULL, 'Sportiva', '1.0'),
('PZOGL3EO82JYO6V7', 'Piano Detox Iniziale', '2023-03-10', NULL, 'Chetogenica', '1.0'),
('PZUWMP3ZO345G6EF', 'Piano Mantenimento', '2023-03-12', NULL, 'Mediterranea', '1.0'),
('PZ3QL2QFKK0RODIN', 'Piano Tonificazione', '2023-03-15', NULL, 'Sportiva', '1.0'),
('PZNTRZEAZ46DGEVW', 'Piano Salute Cardiovascolare', '2023-03-18', NULL, 'Mediterranea', '1.0'),
('PZ7SEUDF38G1JE3E', 'Piano Definizione', '2023-03-20', NULL, 'Chetogenica', '1.0'),
('PZK8XYC94RXHAEQX', 'Piano Bilanciato', '2023-03-22', NULL, 'Mediterranea', '1.0'),
('PZQGZ4IGFF8564MP', 'Piano Performance', '2023-03-25', NULL, 'Sportiva', '1.0'),
('PZW3ALR8K4TNY15Q', 'Piano Benessere Over 60', '2023-03-28', NULL, 'Mediterranea', '1.0'),
('PZRAV4UQU70DOAL7', 'Piano Massa e Forza', '2023-04-01', NULL, 'Sportiva', '1.0'),
('PZ4XTANG7IGCB8U0', 'Piano Equilibrio', '2023-04-03', NULL, 'Mediterranea', '1.0'),
('PZCDRUD9Z3JSF1J9', 'Piano Controllo Glicemico', '2023-04-05', NULL, 'Chetogenica', '1.0'),
('PZIO0M1UKHI1Y6FD', 'Piano Energia', '2023-04-08', NULL, 'Mediterranea', '1.0'),
('PZ4WSAT51562WOVH', 'Piano Anti-age', '2023-04-10', NULL, 'Mediterranea', '1.0'),
('PZ31ZD24CIXJ19YJ', 'Piano Metabolico', '2023-04-12', NULL, 'Chetogenica', '1.0'),
('PZJEK1H5KKM1K4BG', 'Piano Studio e Focus', '2023-04-15', NULL, 'Mediterranea', '1.0'),
('PZ3SLHRNLAYDMAVM', 'Piano Performance Atletica', '2023-04-18', NULL, 'Sportiva', '1.0'),
('PZH8ORUS9NGLNQZS', 'Piano Detossificante', '2023-04-20', NULL, 'Chetogenica', '1.0'),
('PZV6PP8G1DY6OQCM', 'Piano Ipertrofia', '2023-04-22', NULL, 'Sportiva', '1.0'),
('PZRUF8J7824VIDIH', 'Piano Iniziale 2025', '2025-01-10', NULL, 'Mediterranea', '1.0'),
('PZ1V3BW10RXFHU6X', 'Piano Massa 2025', '2025-01-15', NULL, 'Sportiva', '1.0'),
('PZK786XZX5DVGUUW', 'Piano Metabolico 2025', '2025-01-22', NULL, 'Chetogenica', '1.0'),
('PZ8YVWP57KBYF7GA', 'Piano Bilanciato 2025', '2025-02-01', NULL, 'Mediterranea', '1.0'),
('PZQUOHY9IX8X15CG', 'Piano Performance 2025', '2025-02-14', NULL, 'Sportiva', '1.0'),
('PZK70HFEEFRRYQUL', 'Piano Definizione 2025', '2025-03-05', NULL, 'Chetogenica', '1.0'),
('PZ7NFBXQHN8N9EH7', 'Piano Mantenimento 2025', '2025-03-20', NULL, 'Mediterranea', '1.0'),
('PZ4LKLR4EGPN2OIV', 'Piano Forza 2025', '2025-04-01', NULL, 'Sportiva', '1.0'),
('PZT5WPB80UJZEFWT', 'Piano Detox 2025', '2025-04-12', NULL, 'Chetogenica', '1.0'),
('PZDD8P69T4RJ6GEG', 'Piano Salute 2025', '2025-05-02', NULL, 'Mediterranea', '1.0'),
('PZXRA0AMIOH9TISL', 'Piano Benessere Estivo 2025', '2025-05-15', NULL, 'Mediterranea', '1.0'),
('PZKWUVPVN3KM9HF7', 'Piano Ipertrofia 2025', '2025-05-22', NULL, 'Sportiva', '1.0'),
('PZBRZC9J7HPZDAG1', 'Piano Controllo Carboidrati 2025', '2025-06-05', NULL, 'Chetogenica', '1.0'),
('PZNUD1EA1R75M69C', 'Piano Energia 2025', '2025-06-18', NULL, 'Mediterranea', '1.0'),
('PZ312WHL7TEV3TLW', 'Piano Resistenza 2025', '2025-06-25', NULL, 'Sportiva', '1.0'),
('PZ7GHWWJAMT27CYB', 'Piano Reset Metabolico 2025', '2025-07-02', NULL, 'Chetogenica', '1.0'),
('PZYLPWACIQXST8AY', 'Piano Vitalità 2025', '2025-07-10', NULL, 'Mediterranea', '1.0'),
('PZ1STXPBCZ6MEV18', 'Piano Tonificazione 2025', '2025-07-20', NULL, 'Sportiva', '1.0'),
('PZZ0ELPJV2WHYMHA', 'Piano Low Carb 2025', '2025-08-05', NULL, 'Chetogenica', '1.0'),
('PZI5KO0F6BOMPH40', 'Piano Salute Totale 2025', '2025-08-15', NULL, 'Mediterranea', '1.0'),
('PZIEL3MDXQ48LT2K', 'Piano Resistenza 2025', '2025-08-22', NULL, 'Sportiva', '1.0'),
('PZXWYX0G1AJFR3CL', 'Piano Equilibrio Autunno 2025', '2025-09-01', NULL, 'Mediterranea', '1.0'),
('PZIH8EYYULL9FU7V', 'Piano Metabolic Reset 2025', '2025-09-10', NULL, 'Chetogenica', '1.0'),
('PZ6RUBM41Q32XV6L', 'Piano Potenziamento 2025', '2025-09-15', NULL, 'Sportiva', '1.0'),
('PZ4JLJDKE7L7ZVDZ', 'Piano Mantenimento Attivo 2025', '2025-09-25', NULL, 'Mediterranea', '1.0'),
('PZQAQBOZUW37HYM8', 'Piano Low Carb Autunno 2025', '2025-10-02', NULL, 'Chetogenica', '1.0'),
('PZVQZSL3C8GV7M2G', 'Piano Vitalità Donna 2025', '2025-10-12', NULL, 'Mediterranea', '1.0'),
('PZR61JQXYXYTTRP6', 'Piano Forza Senior 2025', '2025-10-20', NULL, 'Sportiva', '1.0'),
('PZ69F9OCTSL8OQKV', 'Piano Salute Ossea 2025', '2025-10-28', NULL, 'Mediterranea', '1.0'),
('PZYQT7RWBNYHZE0C', 'Piano Controllo Peso 2025', '2025-11-05', NULL, 'Chetogenica', '1.0'),
('PZVFBOA5BAD9UJK1', 'Piano Inverno 2025', '2025-11-12', NULL, 'Mediterranea', '1.0'),
('PZR3CY9C8EB13KZ4', 'Piano Massa Inverno', '2025-11-20', NULL, 'Sportiva', '1.0'),
('PZVCX9G4IUP4R06Q', 'Piano Detox Pre-Feste', '2025-12-01', NULL, 'Chetogenica', '1.0'),
('PZYJ0TQI50ZJ6WH1', 'Piano Mantenimento Dicembre', '2025-12-05', NULL, 'Mediterranea', '1.0'),
('PZF794JBKJOLW3BI', 'Piano Tonificazione 2025', '2025-01-18', NULL, 'Sportiva', '1.0'),
('PZLVJZ587CRUSAEU', 'Piano Giovani 2025', '2025-02-10', NULL, 'Mediterranea', '1.0'),
('PZI3C0F1E0RZ6MMR', 'Piano Salute 60+', '2025-03-15', NULL, 'Mediterranea', '1.0'),
('PZ1YPQ82S3XXZAGM', 'Piano Calisthenics', '2025-04-22', NULL, 'Sportiva', '1.0'),
('PZWJ8N9FE2Y5UKXZ', 'Piano Energia Donna', '2025-05-30', NULL, 'Chetogenica', '1.0'),
('PZTMV9635PXNIJUY', 'Piano Estivo Light', '2025-06-12', NULL, 'Mediterranea', '1.0'),
('PZ6UHYJF9EOF24WY', 'Piano Estivo Chetogenico', '2025-06-20', NULL, 'Chetogenica', '1.0'),
('PZ7RQIF7A3YOA6YE', 'Piano Bilanciato Luglio', '2025-07-05', NULL, 'Mediterranea', '1.0'),
('PZH0ROQ8DRAKNSYR', 'Piano Preparazione Atletica', '2025-07-15', NULL, 'Sportiva', '1.0'),
('PZ2O11ZTHSGRZKRR', 'Piano Benessere Agosto', '2025-08-01', NULL, 'Mediterranea', '1.0'),
('PZFX6BNDY6FQ0UCB', 'Piano Rientro Vacanze', '2025-08-20', NULL, 'Chetogenica', '1.0'),
('PZ3TJWIOA9FJFP0A', 'Piano Forza e Resistenza', '2025-09-05', NULL, 'Sportiva', '1.0'),
('PZMQ5MHLHCZJHVHN', 'Piano Autunno Light', '2025-09-15', NULL, 'Mediterranea', '1.0'),
('PZTMWTBH8RTVH0QC', 'Piano Controllo Insulina', '2025-10-01', NULL, 'Chetogenica', '1.0'),
('PZB57F2AI0GI0PQM', 'Piano Ipertrofia Invernale', '2025-10-10', NULL, 'Sportiva', '1.0'),
('PZUVKALVZ27GSXAA', 'Piano Mantenimento Salute', '2025-11-01', NULL, 'Mediterranea', '1.0'),
('PZOZ7HG512ZGQUK6', 'Piano Forza Esplosiva', '2025-01-25', NULL, 'Sportiva', '1.0'),
('PZ8FNF7XVOJQKIGG', 'Piano Bilanciato 2025', '2025-02-12', NULL, 'Mediterranea', '1.0'),
('PZMUYSE7FA5FUDCU', 'Piano Keto Sprint', '2025-03-03', NULL, 'Chetogenica', '1.0'),
('PZBQXZRGTO4MG63I', 'Piano Massa Pulita', '2025-03-22', NULL, 'Sportiva', '1.0'),
('PZ3VDG2QXF5NIXE5', 'Piano Salute Senior', '2025-04-05', NULL, 'Mediterranea', '1.0'),
('PZJDGG5W0YN7UE1B', 'Piano Reset Invernale', '2025-04-18', NULL, 'Chetogenica', '1.0'),
('PZ6CANCTO9JNOXJU', 'Piano Donna Attiva', '2025-05-01', NULL, 'Mediterranea', '1.0'),
('PZW5BOU47891JX3M', 'Piano Recupero Muscolare', '2025-05-14', NULL, 'Sportiva', '1.0'),
('PZWHG5S5IHP593GO', 'Piano Low Carb Estivo', '2025-06-02', NULL, 'Chetogenica', '1.0'),
('PZ954OPOO8TS3462', 'Piano Idrazione e Tono', '2025-06-25', NULL, 'Mediterranea', '1.0'),
('PZFF7KS1SUILY6K9', 'Piano Definizione 2025', '2025-07-01', NULL, 'Chetogenica', '1.0'),
('PZ8HGVM1JSM7CF2F', 'Piano Benessere Uomo', '2025-07-15', NULL, 'Mediterranea', '1.0'),
('PZQOND7F3URO7PT3', 'Piano Salute Donna', '2025-08-02', NULL, 'Mediterranea', '1.0'),
('PZNSM2B991EWV5C1', 'Piano Forza e Massa', '2025-08-18', NULL, 'Sportiva', '1.0'),
('PZW0DATQ3LVQI8X6', 'Piano Metabolico', '2025-09-05', NULL, 'Chetogenica', '1.0'),
('PZUU0LGQPKJ2CKJV', 'Piano Vitalità', '2025-09-20', NULL, 'Mediterranea', '1.0'),
('PZUTG0WWX4JZKYSS', 'Piano Potenziamento', '2025-10-01', NULL, 'Sportiva', '1.0'),
('PZMKLE6733MYEW0X', 'Piano Detox Autunno', '2025-10-15', NULL, 'Chetogenica', '1.0'),
('PZ4UPYZIPTO985J4', 'Piano Massa Invernale', '2025-11-05', NULL, 'Sportiva', '1.0'),
('PZB29909C4QEWU9Z', 'Piano Equilibrio', '2025-11-25', NULL, 'Mediterranea', '1.0'),
('PZFRHJ35HTT1J8OO', 'Piano Detox Invernale', '2025-12-05', NULL, 'Chetogenica', '1.0'),
('PZU5701OF2CMBZDO', 'Piano Mantenimento Attivo', '2025-12-15', NULL, 'Mediterranea', '1.0'),
('PZFCWLQTIEN35N5C', 'Piano Forza 2025', '2025-01-10', NULL, 'Sportiva', '1.0'),
('PZJAKZ75W2P0LO3S', 'Piano Salute Cardiovascolare', '2025-02-20', NULL, 'Mediterranea', '1.0'),
('PZ57T80QHTB7TE17', 'Piano Definizione Muscolare', '2025-03-12', NULL, 'Chetogenica', '1.0'),
('PZUG2IHTC7ANPL3R', 'Piano Benessere Donna', '2025-04-05', NULL, 'Mediterranea', '1.0'),
('PZBJU4KL3T2KBUMU', 'Piano Energia e Vitalità', '2025-05-18', NULL, 'Sportiva', '1.0'),
('PZK50NIVVR9M46CM', 'Piano Metabolico', '2025-06-22', NULL, 'Chetogenica', '1.0'),
('PZ9E0HWUQSG2V2AV', 'Piano Ipertrofia', '2025-07-30', NULL, 'Sportiva', '1.0'),
('PZVS87SY4DY89SCD', 'Piano Equilibrio Giovani', '2025-08-10', NULL, 'Mediterranea', '1.0'),
('PZUHY1MQNTRQDKUA', 'Piano Resistenza 2025', '2025-09-01', NULL, 'Sportiva', '1.0'),
('PZKUS5PVVE8STB4A', 'Piano Equilibrio 2025', '2025-09-12', NULL, 'Mediterranea', '1.0'),
('PZJD074BQDB2IJYW', 'Piano Massa Giovani', '2025-09-25', NULL, 'Sportiva', '1.0'),
('PZ7GU8Q38US8Z6JG', 'Piano Detox Autunnale', '2025-10-05', NULL, 'Chetogenica', '1.0'),
('PZD2P64OLOIY1J2B', 'Piano Salute Cardiovascolare', '2025-10-18', NULL, 'Mediterranea', '1.0'),
('PZZHYMS4V2S2Q5LI', 'Piano Mantenimento Attivo', '2025-11-02', NULL, 'Mediterranea', '1.0'),
('PZZGLQ4Q6K4UJ92J', 'Piano Longevità', '2025-11-15', NULL, 'Mediterranea', '1.0'),
('PZKKKQ5W8D5MH8Q0', 'Piano Definizione Muscolare', '2025-12-01', NULL, 'Chetogenica', '1.0'),
('PZCHS282C9XWI0YA', 'Piano Vitalità Senior', '2025-12-10', NULL, 'Mediterranea', '1.0'),
('PZMOFPQA9P3RRKDB', 'Piano Tonificazione Donna', '2025-01-08', NULL, 'Sportiva', '1.0'),
('PZFZ1XDK4L7WEVIL', 'Piano Detox Primaverile', '2025-02-15', NULL, 'Chetogenica', '1.0'),
('PZMYCOXYZRVKW9SG', 'Piano Salute Donna', '2025-03-01', NULL, 'Mediterranea', '1.0'),
('PZMQWQZMUHHM9RAF', 'Piano Massa Muscolare', '2025-03-20', NULL, 'Sportiva', '1.0'),
('PZC8LNK0WAINTICD', 'Piano Low Carb', '2025-04-10', NULL, 'Chetogenica', '1.0'),
('PZEUFX2Z8E1G7IMX', 'Piano Equilibrio', '2025-05-05', NULL, 'Mediterranea', '1.0'),
('PZINQB8SZ8FWZW63', 'Piano Potenziamento', '2025-05-25', NULL, 'Sportiva', '1.0'),
('PZCB8Y9I2VPA7SHE', 'Piano Definizione Estiva', '2025-06-15', NULL, 'Sportiva', '1.0'),
('PZY6RQ7UBE3U9K78', 'Piano Benessere', '2025-07-01', NULL, 'Mediterranea', '1.0'),
('PZGTIKBPYQC31J07', 'Piano Controllo Peso', '2025-07-20', NULL, 'Chetogenica', '1.0'),
('PZY1G07K39V441X6', 'Piano Performance', '2025-08-10', NULL, 'Sportiva', '1.0'),
('PZ6C18B4N3815DTV', 'Piano Detox Post-Vacanze', '2025-08-25', NULL, 'Chetogenica', '1.0'),
('PZ2G37Q8I377R53U', 'Piano Energia', '2025-09-10', NULL, 'Mediterranea', '1.0'),
('PZIU03I22R7F3C4S', 'Piano Sport Performance', '2025-09-22', NULL, 'Sportiva', '1.0'),
('PZ754E058E5E5899', 'Piano Mantenimento', '2025-10-05', NULL, 'Mediterranea', '1.0'),
('PZR2B756Y2I04746', 'Piano Metabolico', '2025-10-18', NULL, 'Chetogenica', '1.0'),
('PZ58356396956691', 'Piano Forza', '2025-11-01', NULL, 'Sportiva', '1.0'),
('PZ4K419827431289', 'Piano Benessere Giovani', '2025-11-15', NULL, 'Mediterranea', '1.0'),
('PZ74641551676644', 'Piano Ipertrofia', '2025-11-28', NULL, 'Sportiva', '1.0'),
('PZ214532U08G3787', 'Piano Controllo Carboidrati', '2025-12-05', NULL, 'Chetogenica', '1.0'),
('PZ44933923485816', 'Piano Salute Invernale', '2025-12-15', NULL, 'Mediterranea', '1.0'),
('PZK17192N8C9414R', 'Piano Benessere Invernale', '2025-01-05', NULL, 'Mediterranea', '1.0'),
('PZ03E9N2E4P0083B', 'Piano Forza e Massa', '2025-01-18', NULL, 'Sportiva', '1.0'),
('PZ91724654924197', 'Piano Detox Post-Feste', '2025-02-02', NULL, 'Chetogenica', '1.0'),
('PZ94663831818788', 'Piano Longevità', '2025-02-15', NULL, 'Mediterranea', '1.0'),
('PZ15646199343997', 'Piano Mantenimento', '2025-03-01', NULL, 'Mediterranea', '1.0'),
('PZL17J93M01NIO02', 'Piano Definizione', '2025-03-20', NULL, 'Sportiva', '1.0'),
('PZY8V6D3Z35C6R1J', 'Piano Equilibrio Donna', '2025-04-05', NULL, 'Mediterranea', '1.0'),
('PZ29699638787346', 'Piano Reset Metabolico', '2025-04-18', NULL, 'Chetogenica', '1.0'),
('PZY528D69S36214Y', 'Piano Vitalità 50+', '2025-05-02', NULL, 'Mediterranea', '1.0'),
('PZM5I51253C49V28', 'Piano Ipertrofia', '2025-05-15', NULL, 'Sportiva', '1.0'),
('PZ75553641214811', 'Piano Equilibrio 2025', '2025-06-01', NULL, 'Mediterranea', '1.0'),
('PZZK2B2Q3C591W4C', 'Piano Forza', '2025-06-15', NULL, 'Sportiva', '1.0'),
('PZ11679933182885', 'Piano Low Carb', '2025-07-02', NULL, 'Chetogenica', '1.0'),
('PZ21473216853757', 'Piano Benessere', '2025-07-18', NULL, 'Mediterranea', '1.0'),
('PZ6X1X3W3964W08J', 'Piano Tonificazione', '2025-08-01', NULL, 'Sportiva', '1.0'),
('PZ39762143169733', 'Piano Metabolico', '2025-08-14', NULL, 'Chetogenica', '1.0'),
('PZ91599379597371', 'Piano Mantenimento', '2025-09-01', NULL, 'Mediterranea', '1.0'),
('PZ26555194917726', 'Piano Massa', '2025-09-15', NULL, 'Sportiva', '1.0'),
('PZ99324637651794', 'Piano Definizione', '2025-10-01', NULL, 'Chetogenica', '1.0'),
('PZ39832267988882', 'Piano Salute Inverno', '2025-10-15', NULL, 'Mediterranea', '1.0'),
('PZ44778151624467', 'Piano Forza', '2025-11-05', NULL, 'Sportiva', '1.0'),
('PZ45543632938887', 'Piano Benessere', '2025-11-12', NULL, 'Mediterranea', '1.0'),
('PZ39185161314811', 'Piano Low Carb', '2025-11-20', NULL, 'Chetogenica', '1.0'),
('PZ15655762867828', 'Piano Ipertrofia', '2025-11-28', NULL, 'Sportiva', '1.0'),
('PZ31535783359556', 'Piano Salute', '2025-12-02', NULL, 'Mediterranea', '1.0'),
('PZ44975549887752', 'Piano Definizione', '2025-12-05', NULL, 'Chetogenica', '1.0'),
('PZ58334465839655', 'Piano Potenziamento', '2025-12-10', NULL, 'Sportiva', '1.0'),
('PZ44431936319981', 'Piano Equilibrio', '2025-12-12', NULL, 'Mediterranea', '1.0'),
('PZ42668581781224', 'Piano Metabolico', '2025-12-15', NULL, 'Chetogenica', '1.0'),
('PZ16776943825832', 'Piano Performance', '2025-12-18', NULL, 'Sportiva', '1.0'),
('PZ68461715421256', 'Piano Mantenimento', '2025-12-20', NULL, 'Mediterranea', '1.0'),
('PZ49117657922758', 'Piano Detox Fine Anno', '2025-12-22', NULL, 'Chetogenica', '1.0'),
('PZ39758712395565', 'Piano Massa', '2025-12-27', NULL, 'Sportiva', '1.0'),
('PZ39497887349133', 'Piano Vitalità 2026', '2025-12-30', NULL, 'Mediterranea', '1.0');

--piani dieta scaduti (vecchi)
INSERT INTO PIANO_DIETA (cf_paziente, nome, data_inizio, data_fine, nome_dieta, versione_dieta)
VALUES
('PZK0E1YA8PUJBFK5', 'Piano Iniziale 2022', '2022-11-01', '2023-02-28', 'Mediterranea', '1.0'),
('PZMKWDNKRHT6DQA5', 'Piano Adattamento', '2022-12-05', '2023-03-04', 'Sportiva', '1.0'),
('PZOGL3EO82JYO6V7', 'Piano Invernale', '2023-01-10', '2023-03-09', 'Chetogenica', '1.0'),
('PZUWMP3ZO345G6EF', 'Piano Base', '2022-11-12', '2023-03-11', 'Mediterranea', '1.0'),
('PZ3QL2QFKK0RODIN', 'Piano Introduttivo', '2023-01-15', '2023-03-14', 'Sportiva', '1.0'),
('PZNTRZEAZ46DGEVW', 'Piano Conoscitivo', '2022-12-18', '2023-03-17', 'Mediterranea', '1.0'),
('PZ7SEUDF38G1JE3E', 'Piano Post-Feste', '2023-01-20', '2023-03-19', 'Chetogenica', '1.0'),
('PZK8XYC94RXHAEQX', 'Piano Inverno', '2022-11-22', '2023-03-21', 'Mediterranea', '1.0'),
('PZQGZ4IGFF8564MP', 'Piano Pre-Agonistico', '2023-01-25', '2023-03-24', 'Sportiva', '1.0'),
('PZW3ALR8K4TNY15Q', 'Piano Salute 2022', '2022-10-28', '2023-03-27', 'Mediterranea', '1.0');

-- ============================================================
-- COMPOSIZIONE 
-- ============================================================
INSERT INTO COMPOSIZIONE VALUES
('PZE3K372R4203S9C','Piano1','AL01',2,'Consigliato'),
('RSSMRI80A01H501U','Piano2','AL02',1,'Fortemente Consigliato'),
('PZA3ZQSTEG6B0M5G','Piano3','AL03',3,'Consigliato');

-- ============================================================
-- REDAZIONE
-- ============================================================
INSERT INTO REDAZIONE VALUES
('NTRLCU85A01F205X','PZE3K372R4203S9C','Piano1','T01','2023-02-15','09:00'),
('NTRMRC90B02F205Y','RSSMRI80A01H501U','Piano2','T02','2023-02-20','10:00'),
('NTRANN88C03F205Z','PZA3ZQSTEG6B0M5G','Piano3','T03','2023-02-25','11:00');

-- ============================================================
-- ANALISI  
-- ============================================================

INSERT INTO ANALISI
(codice_test, codice_dna, nome_gene, num_prog_gene)
VALUES
('T01','DNA01','FTO',1),
('T02','DNA02','ACE',1),
('T03','DNA03','APOE',1);

-- ============================================================
-- NOTA_TEST  
-- ============================================================

INSERT INTO NOTA_TEST
(codice_test, numero, descrizione)
VALUES
('T01', 1, 'Campione integro, analisi completata'),
('T02', 1, 'Nessuna anomalia nei marcatori principali'),
('T03', 1, 'Suggerita conferma con controllo periodico');

-- ============================================================
-- NOTA_PIANO  
-- ============================================================

INSERT INTO NOTA_PIANO
(cf_paziente, nome_piano, numero, descrizione)
VALUES
('PZE3K372R4203S9C', 'Piano1', 1, 'Bere almeno 2L di acqua al giorno'),
('RSSMRI80A01H501U', 'Piano2', 1, 'Ridurre zuccheri semplici e snack'),
('PZA3ZQSTEG6B0M5G', 'Piano3', 1, 'Distribuire le proteine su tutti i pasti');

INSERT INTO PREDISPOSIZIONI (cf_medico, numero_report, codice, descrizione)
VALUES
('MDCRSS80A01F205X', 'R01', 'PRED_MET_01', 'Tendenza al rallentamento metabolico in condizioni di stress.'),
('MDCBNCH75B02F205', 'R02', 'PRED_INF_02', 'Marcatori infiammatori elevati, predisposizione a infiammazioni articolari.'),
('MDCLVR82C03F205Z', 'R03', 'PRED_VIT_03', 'Ridotta capacità di assorbimento della Vitamina D.');

INSERT INTO CONSIGLIO_MEDICO 
(cf_medico, numero_report, num_progressivo, titolo, descrizione, priorita, tipo_consiglio, tipo_allenamento, durata, intensita, frequenza, tipo_attivita, obiettivo)
VALUES
('MDCRSS80A01F205X', 'R01', 1, 'Attività Aerobica', 'Eseguire attività cardio a bassa intensità per migliorare il metabolismo lipidico.', 'Alta', 'Attività Fisica', 'Cardio', '40 min', 'Moderata', '3/sett', 'Camminata veloce', 'Controllo Peso'),
('MDCBNCH75B02F205', 'R02', 1, 'Rafforzamento Muscolare', 'Esercizi di forza per supportare le articolazioni.', 'Media', 'Attività Fisica', 'Isotonico', '30 min', 'Alta', '2/sett', 'Pesi liberi', 'Tono Muscolare'),
('MDCLVR82C03F205Z', 'R03', 1, 'Esposizione Solare', 'Incrementare esposizione alla luce solare o valutare integrazione.', 'Alta', 'Stile di vita', NULL, NULL, NULL, 'Giornaliera', 'Attività all''aperto', 'Sintesi Vitamina D');


COMMIT;

-- ============================================================
-- TEST: TUPLE DI ESEMPIO CHE MOSTRANO GLI ERRORI DEI TRIGGER
-- (Ogni caso è isolato in una transazione + SAVEPOINT, così il dump può proseguire)
-- RICORDA: fare il rollback dopo che ha dato errore
-- ============================================================

-- 1) trg_check_paziente (BEFORE INSERT ON PAZIENTE)
-- 1.a) Medico inesistente (cf_medico non presente) -> ERRORE: medico non esiste
BEGIN;
SAVEPOINT sp_trg_check_paziente_inesistente;
INSERT INTO PAZIENTE
(cf, nome, cognome, data_nascita, telefono, email, peso, altezza, indirizzo,
 data_inizio_medico, data_inizio_nutrizionista, cf_medico, cf_nutrizionista, citta_residenza)
VALUES
('PZERRMED00000000', 'Test', 'MedicoInesistente', '2000-01-01', '3330000000', 'paziente.err1@email.it',
 70.00, 1.75, 'Via di Prova 1', '2023-01-01', NULL, 'MDN0NESISTENTE00', NULL, 'Bari');
ROLLBACK TO SAVEPOINT sp_trg_check_paziente_inesistente;
RELEASE SAVEPOINT sp_trg_check_paziente_inesistente;
COMMIT;

-- 1.b) Città paziente diversa dalla città studio medico -> ERRORE: incongruenza città
BEGIN;
SAVEPOINT sp_trg_check_paziente_citta;
INSERT INTO PAZIENTE
(cf, nome, cognome, data_nascita, telefono, email, peso, altezza, indirizzo,
 data_inizio_medico, data_inizio_nutrizionista, cf_medico, cf_nutrizionista, citta_residenza)
VALUES
('PZERRCITTA000000', 'Test', 'CittaDiversa', '2001-02-02', '3330000001', 'paziente.err2@email.it',
 65.50, 1.68, 'Via di Prova 2', '2023-01-10', NULL, 'MDCRSS80A01F205X', NULL, 'Roma');
ROLLBACK TO SAVEPOINT sp_trg_check_paziente_citta;
RELEASE SAVEPOINT sp_trg_check_paziente_citta;
COMMIT;


-- 2) trg_derivazione_report_finestra_test (BEFORE INSERT ON DERIVAZIONE)
-- 2.a) Report inesistente -> ERRORE: report inesistente o senza data
BEGIN;
SAVEPOINT sp_trg_deriv_report_inesistente;
INSERT INTO DERIVAZIONE (cf_medico, numero_report, codice_test)
VALUES ('MDCRSS80A01F205X', 'R99', 'T01');
ROLLBACK TO SAVEPOINT sp_trg_deriv_report_inesistente;
RELEASE SAVEPOINT sp_trg_deriv_report_inesistente;
COMMIT;

-- 2.b) Report fuori finestra di validità del test -> Vincolo 4 violato
-- (R03 ha data 2023-02-10; T07 è valido dal 2023-03-10 al 2024-03-10)
BEGIN;
SAVEPOINT sp_trg_deriv_report_fuori_finestra;
INSERT INTO DERIVAZIONE (cf_medico, numero_report, codice_test)
VALUES ('MDCLVR82C03F205Z', 'R03', 'T07');
ROLLBACK TO SAVEPOINT sp_trg_deriv_report_fuori_finestra;
RELEASE SAVEPOINT sp_trg_deriv_report_fuori_finestra;
COMMIT;


-- 3) trg_report_data_check_all_tests (BEFORE UPDATE ON REPORT)
-- Aggiorno la data del report rendendo invalidi i test collegati -> Vincolo 4 violato
BEGIN;
SAVEPOINT sp_trg_update_report_data;
UPDATE REPORT
SET data = '2025-01-01'
WHERE cf_medico = 'MDCRSS80A01F205X' AND numero = 'R01';
ROLLBACK TO SAVEPOINT sp_trg_update_report_data;
RELEASE SAVEPOINT sp_trg_update_report_data;
COMMIT;


-- 4) trg_redazione_finestra_test (BEFORE INSERT ON REDAZIONE)
-- Inserimento con data_creazione fuori finestra test -> Vincolo 5 violato
-- (Uso la stessa PK (cf_paziente, nome_piano) di una riga già presente: il trigger scatta prima della PK)
BEGIN;
SAVEPOINT sp_trg_redazione_fuori_finestra;
INSERT INTO REDAZIONE (cf_nutrizionista, cf_paziente, nome_piano, codice_test, data_creazione, ora_creazione)
VALUES ('NTRLCU85A01F205X', 'PZE3K372R4203S9C', 'Piano1', 'T01', '2025-01-01', '09:30');
ROLLBACK TO SAVEPOINT sp_trg_redazione_fuori_finestra;
RELEASE SAVEPOINT sp_trg_redazione_fuori_finestra;
COMMIT;


-- 5) trg_piano_no_sovrapposizione (BEFORE INSERT ON PIANO_DIETA)
-- 5.a) data_fine precedente a data_inizio -> Vincolo violato: data_fine precedente
BEGIN;
SAVEPOINT sp_trg_piano_date_incoerenti;
INSERT INTO PIANO_DIETA (cf_paziente, nome, data_inizio, data_fine, nome_dieta, versione_dieta)
VALUES ('RSSMRI80A01H501U', 'PianoDateErrate', '2023-03-01', '2023-02-01', 'Mediterranea', '1.0');
ROLLBACK TO SAVEPOINT sp_trg_piano_date_incoerenti;
RELEASE SAVEPOINT sp_trg_piano_date_incoerenti;
COMMIT;

-- 5.b) Sovrapposizione con un piano già attivo (data_fine NULL) -> Vincolo sovrapposizione
BEGIN;
SAVEPOINT sp_trg_piano_sovrapposizione;
INSERT INTO PIANO_DIETA (cf_paziente, nome, data_inizio, data_fine, nome_dieta, versione_dieta)
VALUES ('PZE3K372R4203S9C', 'PianoSovrapposto', '2023-02-11', NULL, 'Chetogenica', '1.0');
ROLLBACK TO SAVEPOINT sp_trg_piano_sovrapposizione;
RELEASE SAVEPOINT sp_trg_piano_sovrapposizione;
COMMIT;



-- nel caso per cancellare:

-- BEGIN;

-- TRUNCATE TABLE
-- DERIVAZIONE,
-- CONSIGLIO_MEDICO,
-- PREDISPOSIZIONI,
-- REDAZIONE,
-- ANALISI,
-- NOTA_TEST,
-- NOTA_PIANO,
-- COMPOSIZIONE,
-- PIANO_DIETA,
-- REPORT,
-- RISULTATO_TEST_GENETICO,
-- GENE,
-- DNA,
-- CERTIFICAZIONE,
-- PAZIENTE,
-- ALIMENTO,
-- DIETA,
-- ABILITAZIONE,
-- NUTRIZIONISTA,
-- MEDICO
-- CASCADE;

-- COMMIT;