BEGIN;

-- ============================================================
-- MEDICO (3)
-- ============================================================
INSERT INTO MEDICO VALUES
('MDCRSS80A01F205X','Mario','Rossi','rossi@med.it','333111','Via Roma 1','Uni Bari','1980-01-01','Bari'),
('MDCBNCH75B02F205','Luigi','Bianchi','bianchi@med.it','333112','Via Napoli 2','Uni Roma','1975-02-02','Bari'),
('MDCLVR82C03F205Z','Paolo','Verdi','verdi@med.it','333113','Via Lecce 3','Uni Milano','1982-03-03','Bari');

-- ============================================================
-- NUTRIZIONISTA (3)
-- ============================================================
INSERT INTO NUTRIZIONISTA VALUES
('NTRLCU85A01F205X','Luca','Neri','1985-01-01','333221','luca@nutri.it','Via Dante 1','Via Bari 1'),
('NTRMRC90B02F205Y','Marco','Rosa','1990-02-02','333222','marco@nutri.it','Via Dante 2','Via Bari 2'),
('NTRANN88C03F205Z','Anna','Blu','1988-03-03','333223','anna@nutri.it','Via Dante 3','Via Bari 3');

-- ============================================================
-- ABILITAZIONE (3)
-- ============================================================
INSERT INTO ABILITAZIONE VALUES
('AB01','Ministero','Nutrizione',3),
('AB02','Ministero','Sport',4),
('AB03','Regione','Clinica',5);

-- ============================================================
-- CERTIFICAZIONE (3)
-- ============================================================
INSERT INTO CERTIFICAZIONE VALUES
('NTRLCU85A01F205X','AB01','2015-01-01'),
('NTRMRC90B02F205Y','AB02','2016-01-01'),
('NTRANN88C03F205Z','AB03','2017-01-01');

-- ============================================================
-- DIETA (3)
-- ============================================================
INSERT INTO DIETA VALUES
('Mediterranea','1.0','Dimagrimento','Bilanciata'),
('Chetogenica','1.0','Definizione','Low Carb'),
('Sportiva','1.0','Performance','Iperproteica');

-- ============================================================
-- ALIMENTO (3)
-- ============================================================
INSERT INTO ALIMENTO VALUES
('AL01','Pasta','Glutine',6,2,12,70,350),
('AL02','Riso',NULL,2,1,7,78,360),
('AL03','Pollo',NULL,0,1,23,0,120);

-- ============================================================
-- PAZIENTE (3 – città = Bari)
-- ============================================================
INSERT INTO PAZIENTE (cf, nome, cognome, data_nascita, telefono, email, peso, altezza, indirizzo, data_inizio_medico, data_inizio_nutrizionista, cf_medico, cf_nutrizionista, citta_residenza) VALUES
('PZK0E1YA8PUJBFK5', 'Laura', 'Leone', '1998-10-21', '3333010064', 'laura.leone.17@email.com', 70.0, 1.64, 'Via Francesca 57', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZMKWDNKRHT6DQA5', 'Davide', 'Rinaldi', '2000-07-12', '3335604935', 'davide.rinaldi.165@email.com', 120.0, 1.88, 'Via Luca 77', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZOGL3EO82JYO6V7', 'Daniela', 'Mariani', '1985-07-26', '3338835773', 'daniela.mariani.3@email.com', 70.0, 1.75, 'Via Vittoria 85', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUWMP3ZO345G6EF', 'Antonio', 'Marchetti', '1995-07-24', '3337780133', 'antonio.marchetti.188@email.com', 70.0, 1.64, 'Via Davide 51', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ3QL2QFKK0RODIN', 'Francesca', 'Rossi', '1998-12-20', '3337771644', 'francesca.rossi.107@email.com', 120.0, 1.65, 'Via Angelo 50', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZNTRZEAZ46DGEVW', 'Roberto', 'Gatti', '1981-11-24', '3336776596', 'roberto.gatti.39@email.com', 70.0, 1.71, 'Via Nicola 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ7SEUDF38G1JE3E', 'Lorenzo', 'Riva', '1985-08-17', '3334012641', 'lorenzo.riva.155@email.com', 70.0, 1.71, 'Via Anna 61', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZK8XYC94RXHAEQX', 'Andrea', 'Bruno', '1998-12-13', '3337396057', 'andrea.bruno.123@email.com', 70.0, 1.73, 'Via Matteo 19', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZQGZ4IGFF8564MP', 'Angelo', 'Romano', '1972-12-04', '3331531522', 'angelo.romano.175@email.com', 70.0, 1.61, 'Via Maria 25', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZW3ALR8K4TNY15Q', 'Elena', 'Caruso', '1963-06-17', '3333866945', 'elena.caruso.44@email.com', 70.0, 1.82, 'Via Pietro 88', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZRAV4UQU70DOAL7', 'Alessandro', 'Riva', '1982-06-20', '3332604320', 'alessandro.riva.48@email.com', 70.0, 1.91, 'Via Angelo 70', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ4XTANG7IGCB8U0', 'Francesca', 'Monti', '1980-09-21', '3337454297', 'francesca.monti.79@email.com', 70.0, 1.91, 'Via Antonio 64', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZCDRUD9Z3JSF1J9', 'Lorenzo', 'Longo', '1961-07-19', '3331657334', 'lorenzo.longo.22@email.com', 70.0, 1.76, 'Via Sofia 78', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZIO0M1UKHI1Y6FD', 'Beatrice', 'Ferrari', '1980-04-15', '3337212808', 'beatrice.ferrari.127@email.com', 70.0, 1.78, 'Via Greta 52', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ4WSAT51562WOVH', 'Silvia', 'Fabbri', '1966-03-18', '3333864771', 'silvia.fabbri.156@email.com', 70.0, 1.74, 'Via Edoardo 60', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ31ZD24CIXJ19YJ', 'Alessia', 'Villa', '1973-07-23', '3332467991', 'alessia.villa.144@email.com', 70.0, 1.72, 'Via Ginevra 76', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZJEK1H5KKM1K4BG', 'Alessia', 'Mazza', '2003-08-17', '3338656608', 'alessia.mazza.86@email.com', 70.0, 1.6, 'Via Laura 73', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ3SLHRNLAYDMAVM', 'Beatrice', 'Marino', '2003-02-18', '3333040584', 'beatrice.marino.145@email.com', 70.0, 1.83, 'Via Davide 52', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZH8ORUS9NGLNQZS', 'Laura', 'Marino', '1977-06-14', '3339466358', 'laura.marino.18@email.com', 70.0, 1.7, 'Via Raffaele 24', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZV6PP8G1DY6OQCM', 'Salvatore', 'Marino', '1990-08-01', '3334194257', 'salvatore.marino.142@email.com', 120.0, 1.65, 'Via Alice 60', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZRUF8J7824VIDIH', 'Paola', 'Rossi', '1981-06-09', '3334870723', 'paola.rossi.116@email.com', 70.0, 1.93, 'Via Nicola 76', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ1V3BW10RXFHU6X', 'Riccardo', 'Rinaldi', '1976-01-22', '3333607723', 'riccardo.rinaldi.8@email.com', 70.0, 1.95, 'Via Angelo 77', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZK786XZX5DVGUUW', 'Ludovica', 'De Santis', '1964-08-24', '3338151407', 'ludovica.desantis.85@email.com', 70.0, 1.65, 'Via Gabriele 13', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ8YVWP57KBYF7GA', 'Andrea', 'Fontana', '1970-03-11', '3337977451', 'andrea.fontana.195@email.com', 70.0, 1.76, 'Via Francesco 51', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZQUOHY9IX8X15CG', 'Michele', 'Parisi', '1989-09-05', '3336954011', 'michele.parisi.102@email.com', 70.0, 1.8, 'Via Valentina 100', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZK70HFEEFRRYQUL', 'Massimo', 'Fontana', '1979-08-10', '3333886708', 'massimo.fontana.87@email.com', 70.0, 1.73, 'Via Elena 13', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ7NFBXQHN8N9EH7', 'Andrea', 'Russo', '1973-10-23', '3335433668', 'andrea.russo.118@email.com', 70.0, 1.93, 'Via Pietro 98', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ4LKLR4EGPN2OIV', 'Pietro', 'Gatti', '1971-12-21', '3333724157', 'pietro.gatti.146@email.com', 70.0, 1.95, 'Via Salvatore 81', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZT5WPB80UJZEFWT', 'Alessia', 'Bruno', '1981-10-24', '3332677995', 'alessia.bruno.89@email.com', 70.0, 1.78, 'Via Arianna 46', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZDD8P69T4RJ6GEG', 'Simone', 'Caruso', '1978-03-16', '3331425560', 'simone.caruso.167@email.com', 70.0, 1.92, 'Via Laura 72', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZXRA0AMIOH9TISL', 'Alice', 'Monti', '1974-06-01', '3334432751', 'alice.monti.27@email.com', 70.0, 1.73, 'Via Paolo 7', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZKWUVPVN3KM9HF7', 'Leonardo', 'Greco', '1988-09-21', '3337426939', 'leonardo.greco.194@email.com', 70.0, 1.79, 'Via Sergio 51', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZBRZC9J7HPZDAG1', 'Maria', 'Fabbri', '1966-12-28', '3337056161', 'maria.fabbri.192@email.com', 70.0, 1.77, 'Via Elena 79', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZNUD1EA1R75M69C', 'Vittoria', 'De Santis', '1964-09-03', '3338504281', 'vittoria.desantis.46@email.com', 70.0, 1.93, 'Via Alice 37', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ312WHL7TEV3TLW', 'Anna', 'Costa', '1994-12-18', '3336059889', 'anna.costa.83@email.com', 70.0, 1.93, 'Via Maria 50', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ7GHWWJAMT27CYB', 'Francesco', 'D''Angelo', '1990-05-19', '3338906999', 'francesco.dangelo.92@email.com', 70.0, 1.94, 'Via Giovanni 8', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZYLPWACIQXST8AY', 'Angelo', 'Mancini', '1986-10-02', '3332522967', 'angelo.mancini.64@email.com', 70.0, 1.78, 'Via Gaia 72', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ1STXPBCZ6MEV18', 'Martina', 'Ferri', '2001-02-17', '3334145906', 'martina.ferri.122@email.com', 70.0, 1.79, 'Via Marco 78', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZZ0ELPJV2WHYMHA', 'Giulia', 'Amato', '1969-01-27', '3332093797', 'giulia.amato.185@email.com', 70.0, 1.71, 'Via Gaia 79', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZI5KO0F6BOMPH40', 'Edoardo', 'Conti', '1972-07-23', '3337958954', 'edoardo.conti.148@email.com', 70.0, 1.72, 'Via Lorenzo 14', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZIEL3MDXQ48LT2K', 'Edoardo', 'De Santis', '1978-04-25', '3331006352', 'edoardo.desantis.5@email.com', 70.0, 1.67, 'Via Antonio 29', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZXWYX0G1AJFR3CL', 'Pietro', 'Bianco', '1998-11-27', '3338358461', 'pietro.bianco.143@email.com', 70.0, 1.76, 'Via Vincenzo 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZIH8EYYULL9FU7V', 'Aurora', 'Costa', '2000-05-11', '3332010759', 'aurora.costa.53@email.com', 70.0, 1.89, 'Via Alice 56', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ6RUBM41Q32XV6L', 'Giuseppe', 'Romano', '2003-04-19', '3334707473', 'giuseppe.romano.104@email.com', 120.0, 1.62, 'Via Federico 14', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ4JLJDKE7L7ZVDZ', 'Salvatore', 'Marino', '2000-11-11', '3333888526', 'salvatore.marino.15@email.com', 70.0, 1.62, 'Via Leonardo 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZQAQBOZUW37HYM8', 'Andrea', 'Giordano', '1988-03-05', '3333127447', 'andrea.giordano.2@email.com', 70.0, 1.65, 'Via Simone 3', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZVQZSL3C8GV7M2G', 'Sofia', 'Vitale', '1996-10-23', '3336380991', 'sofia.vitale.161@email.com', 70.0, 1.79, 'Via Pietro 55', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZR61JQXYXYTTRP6', 'Roberto', 'Barbieri', '1967-05-04', '3337348123', 'roberto.barbieri.125@email.com', 120.0, 1.88, 'Via Giorgio 77', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ69F9OCTSL8OQKV', 'Maria', 'De Santis', '1963-09-08', '3334366827', 'maria.desantis.81@email.com', 70.0, 1.74, 'Via Vittoria 38', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZYQT7RWBNYHZE0C', 'Salvatore', 'Marchetti', '1965-05-22', '3335479619', 'salvatore.marchetti.65@email.com', 70.0, 1.67, 'Via Federico 22', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZVFBOA5BAD9UJK1', 'Paolo', 'Farina', '1968-07-09', '3336829268', 'paolo.farina.162@email.com', 70.0, 1.82, 'Via Nicola 6', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZR3CY9C8EB13KZ4', 'Edoardo', 'Gallo', '1977-12-27', '3335236220', 'edoardo.gallo.105@email.com', 70.0, 1.9, 'Via Aurora 42', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZVCX9G4IUP4R06Q', 'Francesca', 'Bruno', '1985-12-10', '3331229462', 'francesca.bruno.174@email.com', 120.0, 1.65, 'Via Fabio 43', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZYJ0TQI50ZJ6WH1', 'Massimo', 'Parisi', '1979-11-10', '3334560628', 'massimo.parisi.184@email.com', 70.0, 1.75, 'Via Mauro 90', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZF794JBKJOLW3BI', 'Vittoria', 'Fabbri', '1984-05-27', '3338871288', 'vittoria.fabbri.78@email.com', 70.0, 1.88, 'Via Francesca 61', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZLVJZ587CRUSAEU', 'Valentina', 'Greco', '2001-12-06', '3339927553', 'valentina.greco.173@email.com', 70.0, 1.74, 'Via Andrea 85', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZI3C0F1E0RZ6MMR', 'Maria', 'Giordano', '1965-02-27', '3334941237', 'maria.giordano.106@email.com', 70.0, 1.93, 'Via Giorgio 96', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ1YPQ82S3XXZAGM', 'Francesco', 'Galli', '1990-01-02', '3339084320', 'francesco.galli.120@email.com', 70.0, 1.62, 'Via Nicole 69', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZWJ8N9FE2Y5UKXZ', 'Alice', 'Ferraro', '1991-12-14', '3337273485', 'alice.ferraro.113@email.com', 70.0, 1.94, 'Via Paola 81', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZTMV9635PXNIJUY', 'Greta', 'Fontana', '1985-04-11', '3337342765', 'greta.fontana.26@email.com', 70.0, 1.69, 'Via Mattia 37', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ6UHYJF9EOF24WY', 'Simone', 'Villa', '1983-08-09', '3336950096', 'simone.villa.100@email.com', 70.0, 1.77, 'Via Martina 60', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ7RQIF7A3YOA6YE', 'Gabriele', 'Longo', '1970-06-28', '3336645771', 'gabriele.longo.137@email.com', 70.0, 1.82, 'Via Aurora 24', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZH0ROQ8DRAKNSYR', 'Fabio', 'Sanna', '2002-10-11', '3331557120', 'fabio.sanna.186@email.com', 70.0, 1.73, 'Via Arianna 37', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ2O11ZTHSGRZKRR', 'Alessia', 'Monti', '1993-01-09', '3334060861', 'alessia.monti.160@email.com', 70.0, 1.7, 'Via Matteo 55', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZFX6BNDY6FQ0UCB', 'Francesco', 'Esposito', '1967-08-07', '3337153827', 'francesco.esposito.7@email.com', 70.0, 1.66, 'Via Fabio 80', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ3TJWIOA9FJFP0A', 'Daniela', 'Giordano', '1982-09-08', '3336435068', 'daniela.giordano.135@email.com', 70.0, 1.73, 'Via Francesco 96', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMQ5MHLHCZJHVHN', 'Francesca', 'Marchetti', '1979-09-10', '3338995579', 'francesca.marchetti.197@email.com', 120.0, 1.89, 'Via Leonardo 73', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZTMWTBH8RTVH0QC', 'Chiara', 'Romano', '1994-10-07', '3333970739', 'chiara.romano.134@email.com', 70.0, 1.79, 'Via Luca 58', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZB57F2AI0GI0PQM', 'Federico', 'Rizzo', '1990-03-13', '3334987831', 'federico.rizzo.129@email.com', 70.0, 1.76, 'Via Laura 100', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZUVKALVZ27GSXAA', 'Simone', 'Monti', '1962-05-08', '3331110990', 'simone.monti.20@email.com', 70.0, 1.84, 'Via Nicole 21', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZOZ7HG512ZGQUK6', 'Simone', 'Parisi', '1961-07-22', '3334926156', 'simone.parisi.178@email.com', 70.0, 1.93, 'Via Federico 12', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ8FNF7XVOJQKIGG', 'Lorenzo', 'Sanna', '1994-11-03', '3337887926', 'lorenzo.sanna.14@email.com', 70.0, 1.75, 'Via Simone 20', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMUYSE7FA5FUDCU', 'Roberto', 'Fontana', '2000-03-19', '3337840609', 'roberto.fontana.66@email.com', 70.0, 1.9, 'Via Alice 24', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZBQXZRGTO4MG63I', 'Mattia', 'Longo', '1999-07-01', '3331184026', 'mattia.longo.9@email.com', 70.0, 1.73, 'Via Sara 15', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ3VDG2QXF5NIXE5', 'Claudio', 'Colombo', '1961-01-01', '3338503598', 'claudio.colombo.24@email.com', 70.0, 1.68, 'Via Giorgia 69', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZJDGG5W0YN7UE1B', 'Pietro', 'D''Angelo', '1971-06-08', '3332118846', 'pietro.dangelo.190@email.com', 70.0, 1.91, 'Via Claudio 66', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ6CANCTO9JNOXJU', 'Cristina', 'Gallo', '1989-04-23', '3332290335', 'cristina.gallo.115@email.com', 70.0, 1.85, 'Via Alessia 41', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZW5BOU47891JX3M', 'Tommaso', 'Moretti', '1984-06-01', '3332605714', 'tommaso.moretti.131@email.com', 70.0, 1.66, 'Via Emma 94', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZWHG5S5IHP593GO', 'Nicole', 'Montanari', '1975-03-18', '3336238683', 'nicole.montanari.67@email.com', 70.0, 1.8, 'Via Sergio 55', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ954OPOO8TS3462', 'Martina', 'Ricci', '1993-07-13', '3331949752', 'martina.ricci.98@email.com', 70.0, 1.93, 'Via Giovanni 11', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZFF7KS1SUILY6K9', 'Domenico', 'Santoro', '1975-01-02', '3337404677', 'domenico.santoro.60@email.com', 70.0, 1.9, 'Via Giulia 49', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ8HGVM1JSM7CF2F', 'Enrico', 'Farina', '1974-03-13', '3334262758', 'enrico.farina.152@email.com', 70.0, 1.65, 'Via Paolo 19', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZQOND7F3URO7PT3', 'Sara', 'Rizzo', '1967-04-18', '3333300469', 'sara.rizzo.179@email.com', 70.0, 1.63, 'Via Enrico 64', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZNSM2B991EWV5C1', 'Aurora', 'Parisi', '1972-03-25', '3337916667', 'aurora.parisi.80@email.com', 70.0, 1.84, 'Via Silvia 94', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZW0DATQ3LVQI8X6', 'Salvatore', 'Galli', '1986-04-12', '3334096330', 'salvatore.galli.82@email.com', 70.0, 1.8, 'Via Nicole 61', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZUU0LGQPKJ2CKJV', 'Elena', 'Colombo', '1978-03-25', '3337399966', 'elena.colombo.84@email.com', 70.0, 1.85, 'Via Domenico 61', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUTG0WWX4JZKYSS', 'Roberto', 'De Luca', '1985-06-09', '3332982911', 'roberto.deluca.139@email.com', 70.0, 1.82, 'Via Simone 95', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZMKLE6733MYEW0X', 'Riccardo', 'Riva', '1989-11-19', '3332510934', 'riccardo.riva.154@email.com', 70.0, 1.7, 'Via Alice 12', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ4UPYZIPTO985J4', 'Mattia', 'D''Angelo', '1977-03-01', '3331782940', 'mattia.dangelo.149@email.com', 70.0, 1.93, 'Via Beatrice 91', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZB29909C4QEWU9Z', 'Aurora', 'Lombardi', '1990-02-25', '3331243623', 'aurora.lombardi.11@email.com', 70.0, 1.87, 'Via Laura 30', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZFRHJ35HTT1J8OO', 'Francesca', 'Lombardo', '1980-09-01', '3331694972', 'francesca.lombardo.163@email.com', 70.0, 1.62, 'Via Giuseppe 7', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZA3ZQSTEG6B0M5G', 'Paola', 'Bianco', '1970-02-07', '3336940424', 'paola.bianco.168@email.com', 70.0, 1.92, 'Via Camilla 5', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZU5701OF2CMBZDO', 'Lorenzo', 'Ferri', '1998-04-17', '3335009914', 'lorenzo.ferri.199@email.com', 70.0, 1.89, 'Via Antonio 59', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZFCWLQTIEN35N5C', 'Riccardo', 'Vitale', '1987-04-28', '3339981784', 'riccardo.vitale.33@email.com', 70.0, 1.95, 'Via Ginevra 54', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZJAKZ75W2P0LO3S', 'Massimo', 'Rinaldi', '1968-10-19', '3338131697', 'massimo.rinaldi.77@email.com', 70.0, 1.91, 'Via Gaia 93', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ57T80QHTB7TE17', 'Claudio', 'Amato', '1982-09-19', '3334550775', 'claudio.amato.183@email.com', 70.0, 1.76, 'Via Giulia 69', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUG2IHTC7ANPL3R', 'Arianna', 'Russo', '1981-03-19', '3335122521', 'arianna.russo.56@email.com', 70.0, 1.78, 'Via Luigi 7', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZBJU4KL3T2KBUMU', 'Valentina', 'De Luca', '1993-04-19', '3332268451', 'valentina.deluca.19@email.com', 70.0, 1.92, 'Via Rosario 61', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZK50NIVVR9M46CM', 'Vincenzo', 'Santoro', '1966-03-28', '3334078752', 'vincenzo.santoro.103@email.com', 70.0, 1.7, 'Via Federico 23', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ9E0HWUQSG2V2AV', 'Gabriele', 'Testa', '1964-04-22', '3331133058', 'gabriele.testa.140@email.com', 70.0, 1.91, 'Via Luigi 38', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZVS87SY4DY89SCD', 'Antonio', 'Palumbo', '2002-08-02', '3334953624', 'antonio.palumbo.59@email.com', 70.0, 1.61, 'Via Anna 76', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZUHY1MQNTRQDKUA', 'Giuseppe', 'Martinelli', '1989-11-04', '3335922459', 'giuseppe.martinelli.182@email.com', 70.0, 1.87, 'Via Camilla 81', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZKUS5PVVE8STB4A', 'Sofia', 'Cattaneo', '2003-09-19', '3333758943', 'sofia.cattaneo.180@email.com', 70.0, 1.7, 'Via Giorgia 91', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZJD074BQDB2IJYW', 'Alessandro', 'Bruno', '2002-03-24', '3337616174', 'alessandro.bruno.55@email.com', 70.0, 1.68, 'Via Beatrice 56', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ7GU8Q38US8Z6JG', 'Camilla', 'Greco', '1970-02-07', '3333008605', 'camilla.greco.4@email.com', 70.0, 1.8, 'Via Francesco 7', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZD2P64OLOIY1J2B', 'Giovanni', 'Romano', '1961-02-11', '3332318594', 'giovanni.romano.124@email.com', 70.0, 1.87, 'Via Elena 71', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZZHYMS4V2S2Q5LI', 'Simone', 'Barbieri', '1987-11-27', '3333702441', 'simone.barbieri.172@email.com', 70.0, 1.72, 'Via Valentina 42', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZZGLQ4Q6K4UJ92J', 'Maria', 'Farina', '1969-01-15', '3333948077', 'maria.farina.62@email.com', 70.0, 1.91, 'Via Anna 5', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZKKKQ5W8D5MH8Q0', 'Fabio', 'Romano', '1979-04-26', '3333383060', 'fabio.romano.63@email.com', 70.0, 1.61, 'Via Francesca 62', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZCHS282C9XWI0YA', 'Beatrice', 'Ferrara', '1962-01-07', '3338691558', 'beatrice.ferrara.176@email.com', 120.0, 1.63, 'Via Elena 44', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZMOFPQA9P3RRKDB', 'Sofia', 'Greco', '1972-05-17', '3336636081', 'sofia.greco.189@email.com', 70.0, 1.73, 'Via Nicole 13', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZFZ1XDK4L7WEVIL', 'Vittoria', 'Amato', '1983-02-06', '3336530104', 'vittoria.amato.169@email.com', 70.0, 1.72, 'Via Claudio 60', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMYCOXYZRVKW9SG', 'Maria', 'Riva', '1965-08-22', '3332709206', 'maria.riva.42@email.com', 70.0, 1.64, 'Via Roberto 56', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZMQWQZMUHHM9RAF', 'Vincenzo', 'Caruso', '1990-01-14', '3339857892', 'vincenzo.caruso.150@email.com', 70.0, 1.85, 'Via Giuseppe 7', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZC8LNK0WAINTICD', 'Simone', 'Bruno', '1963-04-20', '3338896194', 'simone.bruno.28@email.com', 70.0, 1.84, 'Via Luca 45', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZEUFX2Z8E1G7IMX', 'Elena', 'Villa', '2000-02-09', '3334452429', 'elena.villa.51@email.com', 70.0, 1.86, 'Via Anna 88', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZINQB8SZ8FWZW63', 'Andrea', 'Russo', '1990-07-26', '3338829125', 'andrea.russo.25@email.com', 70.0, 1.92, 'Via Giovanni 31', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZCB8Y9I2VPA7SHE', 'Fabio', 'Farina', '1977-03-17', '3337578390', 'fabio.farina.95@email.com', 70.0, 1.81, 'Via Riccardo 15', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZY6RQ7UBE3U9K78', 'Daniele', 'Testa', '1971-12-08', '3333285849', 'daniele.testa.114@email.com', 70.0, 1.77, 'Via Emma 74', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZGTIKBPYQC31J07', 'Alessia', 'Martini', '1980-10-03', '3335383961', 'alessia.martini.21@email.com', 70.0, 1.9, 'Via Roberto 47', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZY1G07K39V441X6', 'Angelo', 'Conti', '1980-03-05', '3334586675', 'angelo.conti.93@email.com', 70.0, 1.9, 'Via Alessia 77', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ6C18B4N3815DTV', 'Martina', 'Amato', '1972-04-12', '3334641974', 'martina.amato.108@email.com', 70.0, 1.71, 'Via Francesca 33', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ2G37Q8I377R53U', 'Giovanni', 'Lombardi', '1977-10-18', '3338870857', 'giovanni.lombardi.166@email.com', 70.0, 1.63, 'Via Cristina 72', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZIU03I22R7F3C4S', 'Silvia', 'Sanna', '1982-12-07', '3333190866', 'silvia.sanna.13@email.com', 70.0, 1.9, 'Via Antonio 94', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ754E058E5E5899', 'Emma', 'Galli', '1999-04-16', '3334114771', 'emma.galli.111@email.com', 70.0, 1.76, 'Via Beatrice 51', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZR2B756Y2I04746', 'Lorenzo', 'Fontana', '1986-07-06', '3334812351', 'lorenzo.fontana.47@email.com', 70.0, 1.69, 'Via Elena 91', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ58356396956691', 'Giulia', 'Testa', '1984-06-21', '3332407519', 'giulia.testa.68@email.com', 70.0, 1.63, 'Via Francesca 53', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('RSSMRI80A01H501U', 'Mario', 'Speciale', '1980-05-20', '3339999999', 'mario.speciale@mail.it', 80.0, 1.8, 'Via Speciale 1', '2023-01-01', '2023-01-10', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ4K419827431289', 'Ginevra', 'Palumbo', '2001-07-28', '3337920150', 'ginevra.palumbo.10@email.com', 70.0, 1.76, 'Via Simone 89', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ74641551676644', 'Simone', 'Esposito', '1999-01-20', '3339890259', 'simone.esposito.94@email.com', 70.0, 1.83, 'Via Giulia 71', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ214532U08G3787', 'Gabriele', 'Colombo', '1970-07-27', '3333303666', 'gabriele.colombo.136@email.com', 70.0, 1.9, 'Via Roberto 4', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ44933923485816', 'Alessandro', 'Conte', '1999-06-02', '3339943481', 'alessandro.conte.101@email.com', 70.0, 1.78, 'Via Alessia 78', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZK17192N8C9414R', 'Chiara', 'Conte', '1970-05-18', '3333744955', 'chiara.conte.132@email.com', 70.0, 1.91, 'Via Luigi 10', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ03E9N2E4P0083B', 'Stefano', 'Mancini', '1975-01-23', '3334057889', 'stefano.mancini.61@email.com', 70.0, 1.88, 'Via Maria 63', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ91724654924197', 'Giorgia', 'Moretti', '1978-01-16', '3339798485', 'giorgia.moretti.130@email.com', 70.0, 1.79, 'Via Beatrice 22', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZE3K372R4203S9C', 'Salvatore', 'Sanna', '1997-03-01', '3334584218', 'salvatore.sanna.157@email.com', 70.0, 1.85, 'Via Giorgio 37', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ94663831818788', 'Maria', 'Sanna', '1961-04-06', '3334992569', 'maria.sanna.133@email.com', 70.0, 1.74, 'Via Valentina 99', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ15646199343997', 'Giovanni', 'Testa', '1969-02-09', '3332468352', 'giovanni.testa.186@email.com', 70.0, 1.74, 'Via Mattia 47', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZL17J93M01NIO02', 'Luigi', 'Fabbri', '1975-01-20', '3332514330', 'luigi.fabbri.71@email.com', 70.0, 1.83, 'Via Mauro 57', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZY8V6D3Z35C6R1J', 'Aurora', 'Lombardi', '1987-03-23', '3333346581', 'aurora.lombardi.168@email.com', 70.0, 1.63, 'Via Giuseppe 65', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ29699638787346', 'Lorenzo', 'Martinelli', '1987-12-07', '3331908851', 'lorenzo.martinelli.175@email.com', 70.0, 1.63, 'Via Rosario 53', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZY528D69S36214Y', 'Emma', 'Gatti', '1967-12-25', '3335503043', 'emma.gatti.32@email.com', 70.0, 1.84, 'Via Valentina 69', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZM5I51253C49V28', 'Daniele', 'Gallo', '1984-06-18', '3332840590', 'daniele.gallo.8@email.com', 70.0, 1.9, 'Via Francesca 53', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ75553641214811', 'Chiara', 'Gentile', '1994-01-09', '3336687295', 'chiara.gentile.126@email.com', 120.0, 1.83, 'Via Domenico 55', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZZK2B2Q3C591W4C', 'Francesco', 'Pellegrini', '1967-08-27', '3338561138', 'francesco.pellegrini.153@email.com', 70.0, 1.9, 'Via Simona 69', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ11679933182885', 'Sergio', 'Bianco', '1961-07-07', '3336423011', 'sergio.bianco.42@email.com', 70.0, 1.64, 'Via Raffaele 11', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ21473216853757', 'Vittoria', 'Ferri', '1995-11-24', '3334543792', 'vittoria.ferri.133@example.com', 70.0, 1.95, 'Via Ludovica 98', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ6X1X3W3964W08J', 'Ginevra', 'Marchetti', '1969-02-15', '3336302821', 'ginevra.marchetti.150@example.com', 70.0, 1.63, 'Via Mattia 47', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ39762143169733', 'Giorgia', 'Moretti', '1962-09-07', '3336340244', 'giorgia.moretti.87@example.com', 70.0, 1.67, 'Via Ginevra 25', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ91599379597371', 'Giovanni', 'Moretti', '1970-07-16', '3336214619', 'giovanni.moretti.160@example.com', 70.0, 1.69, 'Via Pietro 23', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ26555194917726', 'Anna', 'D''Angelo', '1966-07-28', '3339178978', 'anna.dangelo.187@example.com', 70.0, 1.62, 'Via Sergio 52', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ99324637651794', 'Giulia', 'Lombardi', '1995-10-18', '3333333321', 'giulia.lombardi.153@example.com', 70.0, 1.83, 'Via Davide 73', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ39832267988882', 'Davide', 'De Santis', '1976-11-20', '3337923485', 'davide.de santis.91@example.com', 70.0, 1.77, 'Via Ginevra 7', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ44778151624467', 'Matteo', 'Monti', '1961-09-08', '3335017056', 'matteo.monti.1@example.com', 70.0, 1.84, 'Via Anna 76', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ45543632938887', 'Raffaele', 'Moretti', '1966-03-22', '3336750795', 'raffaele.moretti.98@example.com', 70.0, 1.71, 'Via Arianna 25', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ39185161314811', 'Riccardo', 'Martinelli', '1970-07-16', '3331405096', 'riccardo.martinelli.62@example.com', 70.0, 1.78, 'Via Daniele 90', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ15655762867828', 'Daniele', 'Galli', '1973-10-23', '3336048550', 'daniele.galli.112@example.com', 70.0, 1.83, 'Via Rosario 83', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ31535783359556', 'Gabriele', 'Lombardi', '1967-07-06', '3336906232', 'gabriele.lombardi.198@example.com', 70.0, 1.76, 'Via Massimo 58', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ44975549887752', 'Daniele', 'Fontana', '1972-10-18', '3332766336', 'daniele.fontana.172@example.com', 120.0, 1.9, 'Via Roberto 71', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ58334465839655', 'Roberto', 'De Santis', '1998-05-18', '3331614050', 'roberto.de santis.38@example.com', 70.0, 1.63, 'Via Arianna 90', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ44431936319981', 'Rosario', 'Conte', '1962-09-08', '3331644919', 'rosario.conte.17@example.com', 70.0, 1.77, 'Via Nicola 55', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ42668581781224', 'Angelo', 'Conti', '1967-07-16', '3336961552', 'angelo.conti.95@example.com', 70.0, 1.75, 'Via Claudio 1', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ16776943825832', 'Lorenzo', 'D''Angelo', '1963-01-16', '3336497170', 'lorenzo.dangelo.71@example.com', 70.0, 1.79, 'Via Angelo 83', '2023-01-01', '2023-01-01', 'MDCLVR82C03F205Z', 'NTRLCU85A01F205X', 'Bari'),
('PZ68461715421256', 'Gabriele', 'Marino', '1970-07-27', '3331404118', 'gabriele.marino.146@example.com', 70.0, 1.83, 'Via Rosario 53', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ49117657922758', 'Tommaso', 'De Santis', '1975-02-14', '3337901053', 'tommaso.de santis.152@example.com', 70.0, 1.62, 'Via Roberto 31', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari'),
('PZ39758712395565', 'Emma', 'Galli', '1972-10-18', '3336048590', 'emma.galli.33@example.com', 70.0, 1.71, 'Via Luigi 68', '2023-01-01', '2023-01-01', 'MDCBNCH75B02F205', 'NTRLCU85A01F205X', 'Bari'),
('PZ39497887349133', 'Daniele', 'Bianchi', '1998-05-18', '3338874130', 'daniele.bianchi.28@example.com', 70.0, 1.63, 'Via Pietro 89', '2023-01-01', '2023-01-01', 'MDCRSS80A01F205X', 'NTRLCU85A01F205X', 'Bari');

-- ============================================================
-- DNA (3)
-- ============================================================
INSERT INTO DNA VALUES
('DNA01','Profilo base','PZE3K372R4203S9C'),
('DNA02','Profilo sport','RSSMRI80A01H501U'),
('DNA03','Profilo clinico','PZA3ZQSTEG6B0M5G');

-- ============================================================
-- GENE (3)
-- ============================================================
INSERT INTO GENE VALUES
('DNA01','FTO',1,'Metabolismo'),
('DNA02','ACE',1,'Resistenza'),
('DNA03','APOE',1,'Colesterolo');

-- ============================================================
-- RISULTATO TEST GENETICO (3)
-- ============================================================
INSERT INTO RISULTATO_TEST_GENETICO VALUES
('T01','2023-01-01','2024-01-01','OK','PZE3K372R4203S9C'),
('T02','2023-01-05','2024-01-05','OK','RSSMRI80A01H501U'),
('T03','2023-01-10','2024-01-10','OK','PZA3ZQSTEG6B0M5G');

-- ============================================================
-- REPORT (3 – date dentro test)
-- ============================================================
INSERT INTO REPORT VALUES
('R01','MDCRSS80A01F205X','2023-02-01','Buono'),
('R02','MDCBNCH75B02F205','2023-02-05','Ottimo'),
('R03','MDCLVR82C03F205Z','2023-02-10','Regolare');

-- ============================================================
-- DERIVAZIONE (3)
-- ============================================================
INSERT INTO DERIVAZIONE VALUES
('MDCRSS80A01F205X','R01','T01'),
('MDCBNCH75B02F205','R02','T02'),
('MDCLVR82C03F205Z','R03','T03');

-- ============================================================
-- PIANO_DIETA (3 – no sovrapposizioni)
-- ============================================================
INSERT INTO PIANO_DIETA VALUES
('PZE3K372R4203S9C','Piano1','2023-02-10',NULL,'Mediterranea','1.0'),
('RSSMRI80A01H501U','Piano2','2023-02-15',NULL,'Chetogenica','1.0'),
('PZA3ZQSTEG6B0M5G','Piano3','2023-02-20',NULL,'Sportiva','1.0');

-- ============================================================
-- COMPOSIZIONE (≥3)
-- ============================================================
INSERT INTO COMPOSIZIONE VALUES
('PZE3K372R4203S9C','Piano1','AL01',2,'Consigliato'),
('RSSMRI80A01H501U','Piano2','AL02',1,'Fortemente Consigliato'),
('PZA3ZQSTEG6B0M5G','Piano3','AL03',3,'Consigliato');

-- ============================================================
-- REDAZIONE (3 – data dentro test)
-- ============================================================
INSERT INTO REDAZIONE VALUES
('NTRLCU85A01F205X','PZE3K372R4203S9C','Piano1','T01','2023-02-15','09:00'),
('NTRMRC90B02F205Y','RSSMRI80A01H501U','Piano2','T02','2023-02-20','10:00'),
('NTRANN88C03F205Z','PZA3ZQSTEG6B0M5G','Piano3','T03','2023-02-25','11:00');

-- ============================================================
-- ANALISI (3)
-- ============================================================

INSERT INTO ANALISI
(codice_test, codice_dna, nome_gene, num_prog_gene)
VALUES
('T01','DNA01','FTO',1),
('T02','DNA02','ACE',1),
('T03','DNA03','APOE',1);

-- ============================================================
-- NOTA_TEST (3)
-- ============================================================

INSERT INTO NOTA_TEST
(codice_test, numero, descrizione)
VALUES
('T01', 1, 'Campione integro, analisi completata'),
('T02', 1, 'Nessuna anomalia nei marcatori principali'),
('T03', 1, 'Suggerita conferma con controllo periodico');

-- ============================================================
-- NOTA_PIANO (3)
-- ============================================================

INSERT INTO NOTA_PIANO
(cf_paziente, nome_piano, numero, descrizione)
VALUES
('PZE3K372R4203S9C', 'Piano1', 1, 'Bere almeno 2L di acqua al giorno'),
('RSSMRI80A01H501U', 'Piano2', 1, 'Ridurre zuccheri semplici e snack'),
('PZA3ZQSTEG6B0M5G', 'Piano3', 1, 'Distribuire le proteine su tutti i pasti');


COMMIT;


-- BEGIN;

-- TRUNCATE TABLE
-- DERIVAZIONE,
-- CONSIGLIO_MEDICO,
-- PREDISPOSIZIONI,
-- REDAZIONE,
-- ANALISI,
-- NOTA_TEST,
-- NOTA_PIANO,
-- COMPOSIZIONE,
-- PIANO_DIETA,
-- REPORT,
-- RISULTATO_TEST_GENETICO,
-- GENE,
-- DNA,
-- CERTIFICAZIONE,
-- PAZIENTE,
-- ALIMENTO,
-- DIETA,
-- ABILITAZIONE,
-- NUTRIZIONISTA,
-- MEDICO
-- CASCADE;

-- COMMIT;